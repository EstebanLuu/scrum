import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import type { Database } from "../types/database.types"

export const getSupabaseServer = () => {
  const cookieStore = cookies()

  // Usamos las variables de entorno directamente
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseKey) {
    console.error("Supabase URL or Key is missing")
  }

  return createServerComponentClient<Database>({
    cookies: () => cookieStore,
    supabaseUrl,
    supabaseKey,
  })
}
