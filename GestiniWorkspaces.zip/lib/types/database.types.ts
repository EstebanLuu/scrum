export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          name: string
          avatar_url: string | null
          position: string | null
          company: string | null
          location: string | null
          phone: string | null
          bio: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          name: string
          avatar_url?: string | null
          position?: string | null
          company?: string | null
          location?: string | null
          phone?: string | null
          bio?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          avatar_url?: string | null
          position?: string | null
          company?: string | null
          location?: string | null
          phone?: string | null
          bio?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      contacts: {
        Row: {
          id: string
          name: string
          email: string
          phone: string | null
          company: string | null
          position: string | null
          location: string | null
          notes: string | null
          favorite: boolean
          user_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          phone?: string | null
          company?: string | null
          position?: string | null
          location?: string | null
          notes?: string | null
          favorite?: boolean
          user_id: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          phone?: string | null
          company?: string | null
          position?: string | null
          location?: string | null
          notes?: string | null
          favorite?: boolean
          user_id?: string
          created_at?: string
          updated_at?: string
        }
      }
      contact_tags: {
        Row: {
          id: string
          contact_id: string
          tag: string
        }
        Insert: {
          id?: string
          contact_id: string
          tag: string
        }
        Update: {
          id?: string
          contact_id?: string
          tag?: string
        }
      }
      // Añade aquí el resto de tablas según sea necesario
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
