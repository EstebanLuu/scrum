"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function RegisterPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState<string | null>(null)

  // Función para validar la contraseña
  const validatePassword = (password: string) => {
    const minLength = 8
    const hasUpperCase = /[A-Z]/.test(password)
    const hasNumber = /[0-9]/.test(password)
    const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)

    if (password.length < minLength) {
      return "La contraseña debe tener al menos 8 caracteres"
    }
    if (!hasUpperCase) {
      return "La contraseña debe incluir al menos una letra mayúscula"
    }
    if (!hasNumber) {
      return "La contraseña debe incluir al menos un número"
    }
    if (!hasSymbol) {
      return "La contraseña debe incluir al menos un símbolo"
    }
    return null
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    // Validar que las contraseñas coincidan
    if (password !== confirmPassword) {
      setError("Las contraseñas no coinciden")
      setIsLoading(false)
      return
    }

    // Validar la seguridad de la contraseña
    const passwordError = validatePassword(password)
    if (passwordError) {
      setError(passwordError)
      setIsLoading(false)
      return
    }

    try {
      const supabase = getSupabaseClient()

      console.log("Iniciando registro con Supabase...")

      // Registrar al usuario
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
        },
      })

      if (authError) {
        console.error("Error de autenticación:", authError)

        // Manejar errores específicos de forma segura
        const errorMessage = authError.message || "Error desconocido"

        if (errorMessage.includes && errorMessage.includes("Email already registered")) {
          throw new Error("Este correo electrónico ya está registrado")
        } else if (errorMessage.includes && errorMessage.includes("Password should be at least")) {
          throw new Error("La contraseña no cumple con los requisitos mínimos de seguridad")
        } else {
          throw authError
        }
      }

      console.log("Respuesta de registro:", authData)

      // Si el registro fue exitoso, crear el perfil del usuario
      if (authData?.user) {
        console.log("Creando perfil de usuario...")

        // Obtener la fecha actual en formato ISO
        const now = new Date().toISOString()

        // Intentar crear el perfil del usuario
        const { error: profileError } = await supabase.from("users").insert({
          id: authData.user.id,
          email: email,
          name: name,
          created_at: now,
          updated_at: now,
        })

        if (profileError) {
          console.error("Error al crear perfil:", profileError)

          // Verificar si el error es por un perfil ya existente
          if (profileError.code === "23505") {
            // Código de error para violación de restricción única
            console.log("El perfil ya existe, continuando...")
          } else {
            // Si es otro tipo de error, lanzarlo para que sea manejado
            throw new Error(`Error al crear el perfil: ${profileError.message || JSON.stringify(profileError)}`)
          }
        } else {
          console.log("Perfil creado exitosamente")
        }
      } else {
        console.log("No se recibió información del usuario después del registro")
      }

      toast({
        title: "Cuenta creada",
        description: "Tu cuenta ha sido creada exitosamente. Verifica tu correo electrónico para confirmar tu cuenta.",
      })

      // Redirigir al dashboard
      router.push("/dashboard")
      router.refresh()
    } catch (error: any) {
      console.error("Error completo:", error)

      // Manejar errores específicos de Supabase de forma segura
      const errorMessage = error?.message || "Error al crear la cuenta"

      if (
        typeof errorMessage === "string" &&
        errorMessage.includes &&
        errorMessage.includes("duplicate key value violates unique constraint")
      ) {
        setError("Este correo electrónico ya está registrado")
      } else {
        setError(errorMessage)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <Toaster />
      <Link href="/" className="absolute left-4 top-4 md:left-8 md:top-8">
        <Button variant="ghost">← Volver</Button>
      </Link>
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
        <div className="flex flex-col space-y-2 text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Crea tu cuenta en Gestini</h1>
          <p className="text-sm text-muted-foreground">Regístrate para comenzar a usar Gestini</p>
        </div>

        <Card>
          <form onSubmit={handleRegister}>
            <CardHeader>
              <CardTitle>Crear Cuenta</CardTitle>
              <CardDescription>Completa el formulario para crear tu cuenta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-2">
                <Label htmlFor="name">Nombre completo</Label>
                <Input
                  id="name"
                  placeholder="Tu nombre"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  La contraseña debe tener al menos 8 caracteres, una mayúscula, un número y un símbolo.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirmar contraseña</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full" type="submit" disabled={isLoading}>
                {isLoading ? "Creando cuenta..." : "Crear Cuenta"}
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                ¿Ya tienes una cuenta?{" "}
                <Link href="/login" className="underline underline-offset-4 hover:text-primary">
                  Inicia sesión
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
