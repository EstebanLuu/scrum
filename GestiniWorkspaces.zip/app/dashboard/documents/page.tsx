"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle, Loader2 } from "lucide-react"
import { DocumentsExplorer } from "@/components/documents/documents-explorer"
import { CreateDocumentDialog } from "@/components/documents/create-document-dialog"
import { getSupabaseClient } from "@/lib/supabase/client"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

export default function DocumentsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)
  const [documentsUpdated, setDocumentsUpdated] = useState(0)

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const supabase = getSupabaseClient()
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user) {
          setUserId(session.user.id)
        } else {
          window.location.href = "/login"
        }
      } catch (error) {
        console.error("Error al verificar la autenticación:", error)
        toast({
          title: "Error",
          description: "No se pudo verificar la autenticación. Por favor, inicia sesión de nuevo.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  const handleDocumentCreated = () => {
    // Incrementar el contador para forzar la actualización del componente DocumentsExplorer
    setDocumentsUpdated((prev) => prev + 1)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Cargando documentos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Toaster />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Documentos</h1>
          <p className="text-muted-foreground">Crea y organiza tus documentos con formato enriquecido.</p>
        </div>
        <CreateDocumentDialog userId={userId} onDocumentCreated={handleDocumentCreated}>
          <Button className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            Nuevo Documento
          </Button>
        </CreateDocumentDialog>
      </div>

      <DocumentsExplorer userId={userId} key={documentsUpdated} />
    </div>
  )
}
