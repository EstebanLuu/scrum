"use client"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Download, Save } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

export default function DocumentEditorPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [title, setTitle] = useState("Documento sin título")
  const [content, setContent] = useState("<p>Comienza a escribir aquí...</p>")
  const [isSaving, setIsSaving] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const editorRef = useRef<HTMLDivElement>(null)

  // Simular carga del documento
  useEffect(() => {
    const timer = setTimeout(() => {
      // Aquí se cargaría el documento desde la API
      setIsLoading(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [params.id])

  const handleSave = () => {
    setIsSaving(true)

    // Simulando guardado
    setTimeout(() => {
      setIsSaving(false)
      toast({
        title: "Documento guardado",
        description: "Tu documento ha sido guardado correctamente.",
      })
    }, 1000)
  }

  const handleDownload = () => {
    // Crear un objeto Blob con el contenido HTML
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${title}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          h1 { color: #333; }
        </style>
      </head>
      <body>
        <h1>${title}</h1>
        ${editorRef.current?.innerHTML || content}
      </body>
      </html>
    `

    const blob = new Blob([htmlContent], { type: "application/msword" })
    const url = URL.createObjectURL(blob)

    // Crear un enlace para descargar
    const a = document.createElement("a")
    a.href = url
    a.download = `${title}.doc`
    document.body.appendChild(a)
    a.click()

    // Limpiar
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Documento descargado",
      description: "Tu documento ha sido descargado en formato Word.",
    })
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6 flex items-center justify-center h-[70vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Cargando documento...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Toaster />

      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver
        </Button>

        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleDownload}>
            <Download className="mr-2 h-4 w-4" />
            Descargar como Word
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Guardando..." : "Guardar"}
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-xl font-bold border-none text-center"
          placeholder="Título del documento"
        />

        <Card className="p-6 min-h-[60vh]">
          <div
            ref={editorRef}
            contentEditable
            className="outline-none min-h-[58vh]"
            dangerouslySetInnerHTML={{ __html: content }}
            onInput={(e) => setContent(e.currentTarget.innerHTML)}
          />
        </Card>
      </div>
    </div>
  )
}
