"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Briefcase,
  Copy,
  Edit,
  Loader2,
  Mail,
  MapPin,
  MoreHorizontal,
  Phone,
  Plus,
  Search,
  Share2,
  Star,
  Trash2,
  User,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"
import { EditContactDialog } from "@/components/contacts/edit-contact-dialog"

type Contact = Tables<"contacts"> & {
  tags: string[]
}

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)
  const [showAddContactDialog, setShowAddContactDialog] = useState(false)
  const [showEditContactDialog, setShowEditContactDialog] = useState(false)
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null)
  const [newContact, setNewContact] = useState<Partial<Contact>>({
    name: "",
    email: "",
    phone: "",
    company: "",
    position: "",
    location: "",
    notes: "",
    favorite: false,
    tags: [],
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTag, setSelectedTag] = useState<string | null>(null)
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false)
  const [allTags, setAllTags] = useState<string[]>([])

  // Obtener el ID del usuario y los contactos al cargar la página
  useEffect(() => {
    const fetchUserAndContacts = async () => {
      try {
        const supabase = getSupabaseClient()

        // Obtener la sesión actual
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user) {
          setUserId(session.user.id)

          // Obtener los contactos del usuario
          await fetchContacts(session.user.id)
        } else {
          // Si no hay sesión, redirigir al login
          window.location.href = "/login"
        }
      } catch (error) {
        console.error("Error al obtener datos:", error)
        toast({
          title: "Error",
          description: "No se pudieron cargar los contactos. Por favor, intenta de nuevo.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserAndContacts()
  }, [])

  // Función para obtener los contactos del usuario
  const fetchContacts = async (userId: string) => {
    try {
      const supabase = getSupabaseClient()

      // Obtener los contactos
      const { data: contactsData, error: contactsError } = await supabase
        .from("contacts")
        .select("*")
        .eq("user_id", userId)
        .order("name")

      if (contactsError) {
        throw contactsError
      }

      // Para cada contacto, obtener sus etiquetas
      const contactsWithTags = await Promise.all(
        contactsData.map(async (contact) => {
          const { data: tagsData, error: tagsError } = await supabase
            .from("contact_tags")
            .select("tag")
            .eq("contact_id", contact.id)

          if (tagsError) {
            throw tagsError
          }

          return {
            ...contact,
            tags: tagsData.map((t) => t.tag),
          }
        }),
      )

      setContacts(contactsWithTags)

      // Obtener todas las etiquetas únicas
      const allTagsSet = new Set<string>()
      contactsWithTags.forEach((contact) => {
        contact.tags.forEach((tag) => allTagsSet.add(tag))
      })

      setAllTags(Array.from(allTagsSet))
    } catch (error) {
      console.error("Error al obtener contactos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los contactos. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  // Filtrar contactos
  const filteredContacts = contacts.filter((contact) => {
    // Filtrar por término de búsqueda
    const matchesSearch =
      searchTerm === "" ||
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (contact.company && contact.company.toLowerCase().includes(searchTerm.toLowerCase()))

    // Filtrar por etiqueta
    const matchesTag = selectedTag === null || contact.tags.includes(selectedTag)

    // Filtrar por favoritos
    const matchesFavorite = !showOnlyFavorites || contact.favorite

    return matchesSearch && matchesTag && matchesFavorite
  })

  const addContact = async () => {
    if (!newContact.name || !newContact.email || !userId) {
      toast({
        title: "Error",
        description: "El nombre y el email son obligatorios.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const supabase = getSupabaseClient()

      // Insertar el contacto
      const { data: contactData, error: contactError } = await supabase
        .from("contacts")
        .insert({
          name: newContact.name,
          email: newContact.email,
          phone: newContact.phone || null,
          company: newContact.company || null,
          position: newContact.position || null,
          location: newContact.location || null,
          notes: newContact.notes || null,
          favorite: newContact.favorite || false,
          user_id: userId,
        })
        .select()
        .single()

      if (contactError) {
        throw contactError
      }

      // Insertar las etiquetas del contacto
      if (newContact.tags && newContact.tags.length > 0) {
        const tagInserts = newContact.tags.map((tag) => ({
          contact_id: contactData.id,
          tag: tag,
        }))

        const { error: tagsError } = await supabase.from("contact_tags").insert(tagInserts)

        if (tagsError) {
          throw tagsError
        }
      }

      // Actualizar la lista de contactos
      await fetchContacts(userId)

      // Limpiar el formulario
      setNewContact({
        name: "",
        email: "",
        phone: "",
        company: "",
        position: "",
        location: "",
        notes: "",
        favorite: false,
        tags: [],
      })

      setShowAddContactDialog(false)

      toast({
        title: "Contacto añadido",
        description: "El contacto ha sido añadido correctamente.",
      })
    } catch (error: any) {
      console.error("Error al añadir contacto:", error)
      toast({
        title: "Error",
        description: error.message || "Error al añadir el contacto. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const deleteContact = async (contactId: string) => {
    if (!userId) return

    try {
      const supabase = getSupabaseClient()

      // Eliminar el contacto (las etiquetas se eliminarán automáticamente por la restricción ON DELETE CASCADE)
      const { error } = await supabase.from("contacts").delete().eq("id", contactId).eq("user_id", userId) // Asegurarse de que el contacto pertenece al usuario

      if (error) {
        throw error
      }

      // Actualizar la lista de contactos
      await fetchContacts(userId)

      toast({
        title: "Contacto eliminado",
        description: "El contacto ha sido eliminado correctamente.",
      })
    } catch (error: any) {
      console.error("Error al eliminar contacto:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar el contacto. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const toggleFavorite = async (contactId: string, currentFavorite: boolean) => {
    if (!userId) return

    try {
      const supabase = getSupabaseClient()

      // Actualizar el estado de favorito del contacto
      const { error } = await supabase
        .from("contacts")
        .update({ favorite: !currentFavorite })
        .eq("id", contactId)
        .eq("user_id", userId) // Asegurarse de que el contacto pertenece al usuario

      if (error) {
        throw error
      }

      // Actualizar la lista de contactos
      await fetchContacts(userId)
    } catch (error: any) {
      console.error("Error al actualizar favorito:", error)
      toast({
        title: "Error",
        description: error.message || "Error al actualizar el contacto. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const shareContact = (contact: Contact) => {
    // Crear vCard
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${contact.name}
EMAIL:${contact.email}
TEL:${contact.phone || ""}
ORG:${contact.company || ""}
TITLE:${contact.position || ""}
ADR:;;${contact.location || ""};;;
NOTE:${contact.notes || ""}
END:VCARD`

    // Copiar al portapapeles
    navigator.clipboard.writeText(vcard).then(() => {
      toast({
        title: "Contacto compartido",
        description: "La información del contacto ha sido copiada al portapapeles.",
      })
    })
  }

  const editContact = (contact: Contact) => {
    setSelectedContact(contact)
    setShowEditContactDialog(true)
  }

  const addTag = (tag: string) => {
    if (tag && !newContact.tags?.includes(tag)) {
      setNewContact({
        ...newContact,
        tags: [...(newContact.tags || []), tag],
      })
    }
  }

  const removeTag = (tag: string) => {
    setNewContact({
      ...newContact,
      tags: newContact.tags?.filter((t) => t !== tag) || [],
    })
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6 flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Cargando contactos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Toaster />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Contactos</h1>
          <p className="text-muted-foreground">Gestiona tus contactos personales y profesionales.</p>
        </div>

        <Dialog open={showAddContactDialog} onOpenChange={setShowAddContactDialog}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              Nuevo contacto
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Añadir nuevo contacto</DialogTitle>
              <DialogDescription>Añade un nuevo contacto a tu directorio.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Nombre completo *</Label>
                  <Input
                    id="name"
                    value={newContact.name}
                    onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                    placeholder="Nombre y apellidos"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newContact.email}
                    onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                    placeholder="email@ejemplo.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    value={newContact.phone}
                    onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                    placeholder="+34 600 000 000"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="location">Ubicación</Label>
                  <Input
                    id="location"
                    value={newContact.location}
                    onChange={(e) => setNewContact({ ...newContact, location: e.target.value })}
                    placeholder="Ciudad, País"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="company">Empresa</Label>
                  <Input
                    id="company"
                    value={newContact.company}
                    onChange={(e) => setNewContact({ ...newContact, company: e.target.value })}
                    placeholder="Nombre de la empresa"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="position">Cargo</Label>
                  <Input
                    id="position"
                    value={newContact.position}
                    onChange={(e) => setNewContact({ ...newContact, position: e.target.value })}
                    placeholder="Cargo o puesto"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="tags">Etiquetas</Label>
                <div className="flex gap-2">
                  <Input
                    id="new-tag"
                    placeholder="Añadir etiqueta"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        addTag(e.currentTarget.value)
                        e.currentTarget.value = ""
                      }
                    }}
                  />
                  <Select
                    onValueChange={(value) => {
                      if (value) {
                        addTag(value)
                      }
                    }}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Etiquetas comunes" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cliente">Cliente</SelectItem>
                      <SelectItem value="proveedor">Proveedor</SelectItem>
                      <SelectItem value="socio">Socio</SelectItem>
                      <SelectItem value="personal">Personal</SelectItem>
                      <SelectItem value="trabajo">Trabajo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newContact.tags && newContact.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {newContact.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="gap-1">
                        {tag}
                        <button onClick={() => removeTag(tag)} className="ml-1 rounded-full hover:bg-muted">
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="notes">Notas</Label>
                <Input
                  id="notes"
                  value={newContact.notes}
                  onChange={(e) => setNewContact({ ...newContact, notes: e.target.value })}
                  placeholder="Información adicional sobre el contacto"
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="favorite"
                  checked={newContact.favorite}
                  onChange={(e) => setNewContact({ ...newContact, favorite: e.target.checked })}
                  className="rounded border-gray-300 text-primary focus:ring-primary"
                />
                <Label htmlFor="favorite">Marcar como favorito</Label>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={addContact} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Añadiendo...
                  </>
                ) : (
                  "Añadir contacto"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-64 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar contactos..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Etiquetas</Label>
                <div className="space-y-1">
                  <Button
                    variant={selectedTag === null ? "default" : "outline"}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setSelectedTag(null)}
                  >
                    Todas
                  </Button>
                  {allTags.map((tag) => (
                    <Button
                      key={tag}
                      variant={selectedTag === tag ? "default" : "outline"}
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => setSelectedTag(tag)}
                    >
                      {tag}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Opciones</Label>
                <Button
                  variant={showOnlyFavorites ? "default" : "outline"}
                  size="sm"
                  className="w-full justify-start gap-2"
                  onClick={() => setShowOnlyFavorites(!showOnlyFavorites)}
                >
                  <Star className="h-4 w-4" />
                  Solo favoritos
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estadísticas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Total de contactos:</span>
                  <span className="font-medium">{contacts.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Favoritos:</span>
                  <span className="font-medium">{contacts.filter((c) => c.favorite).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Etiquetas:</span>
                  <span className="font-medium">{allTags.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <Tabs defaultValue="grid" className="space-y-4">
            <div className="flex justify-between items-center">
              <TabsList>
                <TabsTrigger value="grid">Cuadrícula</TabsTrigger>
                <TabsTrigger value="list">Lista</TabsTrigger>
              </TabsList>

              <div className="text-sm text-muted-foreground">
                Mostrando {filteredContacts.length} de {contacts.length} contactos
              </div>
            </div>

            <TabsContent value="grid">
              {filteredContacts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredContacts.map((contact) => (
                    <Card key={contact.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-12 w-12">
                              <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <CardTitle className="text-lg flex items-center gap-1">
                                {contact.name}
                                {contact.favorite && <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />}
                              </CardTitle>
                              <CardDescription>{contact.position}</CardDescription>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => editContact(contact)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar contacto
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toggleFavorite(contact.id, contact.favorite)}>
                                <Star className="mr-2 h-4 w-4" />
                                {contact.favorite ? "Quitar de favoritos" : "Añadir a favoritos"}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => shareContact(contact)}>
                                <Share2 className="mr-2 h-4 w-4" />
                                Compartir contacto
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => deleteContact(contact.id)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Eliminar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-muted-foreground" />
                            <span>{contact.email}</span>
                          </div>
                          {contact.phone && (
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <span>{contact.phone}</span>
                            </div>
                          )}
                          {contact.company && (
                            <div className="flex items-center gap-2">
                              <Briefcase className="h-4 w-4 text-muted-foreground" />
                              <span>{contact.company}</span>
                            </div>
                          )}
                          {contact.location && (
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-muted-foreground" />
                              <span>{contact.location}</span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-2">
                        <div className="flex flex-wrap gap-1">
                          {contact.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <User className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-2">No se encontraron contactos</p>
                  <Button variant="outline" onClick={() => setShowAddContactDialog(true)}>
                    Añadir contacto
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="list">
              <Card>
                <CardContent className="p-0">
                  {filteredContacts.length > 0 ? (
                    <div className="divide-y">
                      {filteredContacts.map((contact) => (
                        <div key={contact.id} className="flex items-center justify-between p-4 hover:bg-muted/50">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium flex items-center gap-1">
                                {contact.name}
                                {contact.favorite && <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />}
                              </div>
                              <div className="text-sm text-muted-foreground flex items-center gap-1">
                                <Mail className="h-3 w-3" />
                                {contact.email}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                navigator.clipboard.writeText(contact.email)
                                toast({
                                  title: "Email copiado",
                                  description: "El email ha sido copiado al portapapeles.",
                                })
                              }}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => editContact(contact)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => toggleFavorite(contact.id, contact.favorite)}
                            >
                              <Star
                                className={`h-4 w-4 ${contact.favorite ? "fill-yellow-400 text-yellow-400" : ""}`}
                              />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => deleteContact(contact.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <User className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-muted-foreground mb-2">No se encontraron contactos</p>
                      <Button variant="outline" onClick={() => setShowAddContactDialog(true)}>
                        Añadir contacto
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Diálogo de edición de contacto */}
      <EditContactDialog
        open={showEditContactDialog}
        onOpenChange={setShowEditContactDialog}
        contact={selectedContact}
        onContactUpdated={() => fetchContacts(userId!)}
      />
    </div>
  )
}
