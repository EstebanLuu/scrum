import type React from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { SidebarNav } from "@/components/dashboard/sidebar-nav"
import { AuthCheck } from "@/components/auth/auth-check"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <AuthCheck>
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <div className="flex flex-1">
          <aside className="hidden w-64 border-r bg-background md:block">
            <div className="flex h-full flex-col gap-2 p-4">
              <SidebarNav className="flex-1" />
            </div>
          </aside>
          <main className="flex-1 p-4 md:p-6">{children}</main>
        </div>
      </div>
    </AuthCheck>
  )
}
