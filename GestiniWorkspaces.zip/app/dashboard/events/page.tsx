"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { CalendarIcon, Clock, Loader2, MapPin, Plus, Trash2 } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"

type Event = Tables<"events"> & {
  workspace_name?: string
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [showAddEventDialog, setShowAddEventDialog] = useState(false)
  const [workspaces, setWorkspaces] = useState<{ id: string; name: string }[]>([])
  const [newEvent, setNewEvent] = useState<Partial<Event>>({
    title: "",
    description: "",
    date: new Date(),
    start_time: "09:00",
    end_time: "10:00",
    location: "",
    type: "meeting",
    workspace_id: null,
  })

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const supabase = getSupabaseClient()
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user) {
          setUserId(session.user.id)
          await fetchEvents(session.user.id)
          await fetchWorkspaces(session.user.id)
        } else {
          window.location.href = "/login"
        }
      } catch (error) {
        console.error("Error al verificar la autenticación:", error)
        toast({
          title: "Error",
          description: "No se pudo verificar la autenticación. Por favor, inicia sesión de nuevo.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  const fetchEvents = async (userId: string) => {
    try {
      const supabase = getSupabaseClient()

      // Obtener los eventos del usuario
      const { data: eventsData, error: eventsError } = await supabase
        .from("events")
        .select("*, workspaces(name)")
        .eq("user_id", userId)
        .order("date")
        .order("start_time")

      if (eventsError) {
        throw eventsError
      }

      // Formatear los datos para incluir el nombre del espacio de trabajo
      const formattedEvents = eventsData.map((event) => ({
        ...event,
        workspace_name: event.workspaces ? (event.workspaces as any).name : null,
      }))

      setEvents(formattedEvents)
    } catch (error) {
      console.error("Error al obtener eventos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los eventos. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const fetchWorkspaces = async (userId: string) => {
    try {
      const supabase = getSupabaseClient()

      // Obtener los espacios de trabajo del usuario
      const { data, error } = await supabase.from("workspaces").select("id, name").eq("user_id", userId).order("name")

      if (error) {
        throw error
      }

      setWorkspaces(data)
    } catch (error) {
      console.error("Error al obtener espacios de trabajo:", error)
    }
  }

  const addEvent = async () => {
    if (!newEvent.title || !newEvent.date || !userId) {
      toast({
        title: "Error",
        description: "El título y la fecha del evento son obligatorios.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Formatear la fecha para la base de datos
      const formattedDate = format(newEvent.date, "yyyy-MM-dd")

      // Crear el evento
      const { error } = await supabase.from("events").insert({
        title: newEvent.title,
        description: newEvent.description || null,
        date: formattedDate,
        start_time: newEvent.start_time || null,
        end_time: newEvent.end_time || null,
        location: newEvent.location || null,
        type: newEvent.type as "meeting" | "deadline" | "reminder" | "other",
        workspace_id: newEvent.workspace_id || null,
        user_id: userId,
      })

      if (error) {
        throw error
      }

      // Actualizar la lista de eventos
      await fetchEvents(userId)

      // Limpiar el formulario
      setNewEvent({
        title: "",
        description: "",
        date: new Date(),
        start_time: "09:00",
        end_time: "10:00",
        location: "",
        type: "meeting",
        workspace_id: null,
      })

      setShowAddEventDialog(false)

      toast({
        title: "Evento añadido",
        description: "El evento ha sido añadido correctamente.",
      })
    } catch (error: any) {
      console.error("Error al añadir evento:", error)
      toast({
        title: "Error",
        description: error.message || "Error al añadir el evento. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const deleteEvent = async (eventId: string) => {
    if (!userId) return

    try {
      const supabase = getSupabaseClient()

      // Eliminar el evento
      const { error } = await supabase.from("events").delete().eq("id", eventId).eq("user_id", userId)

      if (error) {
        throw error
      }

      // Actualizar la lista de eventos
      await fetchEvents(userId)

      toast({
        title: "Evento eliminado",
        description: "El evento ha sido eliminado correctamente.",
      })
    } catch (error: any) {
      console.error("Error al eliminar evento:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar el evento. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "meeting":
        return "bg-blue-500"
      case "deadline":
        return "bg-red-500"
      case "reminder":
        return "bg-yellow-500"
      default:
        return "bg-gray-500"
    }
  }

  const getEventTypeBadge = (type: string) => {
    switch (type) {
      case "meeting":
        return <Badge className="bg-blue-500">Reunión</Badge>
      case "deadline":
        return <Badge className="bg-red-500">Fecha límite</Badge>
      case "reminder":
        return <Badge className="bg-yellow-500">Recordatorio</Badge>
      default:
        return <Badge>Otro</Badge>
    }
  }

  // Filtrar eventos por fecha seleccionada
  const filteredEvents = date
    ? events.filter((event) => {
        const eventDate = new Date(event.date)
        return (
          eventDate.getDate() === date.getDate() &&
          eventDate.getMonth() === date.getMonth() &&
          eventDate.getFullYear() === date.getFullYear()
        )
      })
    : events

  // Ordenar eventos por hora de inicio
  const sortedEvents = [...filteredEvents].sort((a, b) => {
    return (a.start_time || "").localeCompare(b.start_time || "")
  })

  if (isLoading && events.length === 0) {
    return (
      <div className="container mx-auto py-6 flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Cargando eventos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Toaster />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Eventos</h1>
          <p className="text-muted-foreground">Gestiona tus eventos y recordatorios.</p>
        </div>

        <Dialog open={showAddEventDialog} onOpenChange={setShowAddEventDialog}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              Nuevo evento
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Añadir nuevo evento</DialogTitle>
              <DialogDescription>Crea un nuevo evento en tu calendario.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  placeholder="Ej: Reunión de equipo"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                  placeholder="Describe el evento"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Fecha</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !newEvent.date && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {newEvent.date ? (
                          format(newEvent.date, "PPP", { locale: es })
                        ) : (
                          <span>Selecciona una fecha</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={newEvent.date}
                        onSelect={(date) => setNewEvent({ ...newEvent, date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="type">Tipo</Label>
                  <Select
                    value={newEvent.type}
                    onValueChange={(value) => setNewEvent({ ...newEvent, type: value as any })}
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Selecciona un tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="meeting">Reunión</SelectItem>
                      <SelectItem value="deadline">Fecha límite</SelectItem>
                      <SelectItem value="reminder">Recordatorio</SelectItem>
                      <SelectItem value="other">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="startTime">Hora de inicio</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={newEvent.start_time}
                    onChange={(e) => setNewEvent({ ...newEvent, start_time: e.target.value })}
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="endTime">Hora de fin</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={newEvent.end_time}
                    onChange={(e) => setNewEvent({ ...newEvent, end_time: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="location">Ubicación</Label>
                <Input
                  id="location"
                  value={newEvent.location}
                  onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                  placeholder="Ej: Sala de conferencias A"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="workspace">Espacio de trabajo</Label>
                <Select
                  value={newEvent.workspace_id || "null"}
                  onValueChange={(value) => setNewEvent({ ...newEvent, workspace_id: value || null })}
                >
                  <SelectTrigger id="workspace">
                    <SelectValue placeholder="Selecciona un espacio" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="null">Sin espacio</SelectItem>
                    {workspaces.map((workspace) => (
                      <SelectItem key={workspace.id} value={workspace.id}>
                        {workspace.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={addEvent} disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Añadiendo...
                  </>
                ) : (
                  "Añadir evento"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="calendar" className="space-y-4">
        <TabsList>
          <TabsTrigger value="calendar">Calendario</TabsTrigger>
          <TabsTrigger value="list">Lista</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Calendario</CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" locale={es} />
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>{date ? format(date, "PPPP", { locale: es }) : "Todos los eventos"}</CardTitle>
                <CardDescription>
                  {sortedEvents.length} evento{sortedEvents.length !== 1 ? "s" : ""}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {sortedEvents.length > 0 ? (
                  <div className="space-y-4">
                    {sortedEvents.map((event) => (
                      <div
                        key={event.id}
                        className="flex items-start space-x-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                      >
                        <div className={`w-1 self-stretch rounded-full ${getEventTypeColor(event.type)}`}></div>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{event.title}</h3>
                            {getEventTypeBadge(event.type)}
                          </div>
                          <p className="text-sm text-muted-foreground">{event.description}</p>
                          <div className="flex flex-wrap gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                              <span>{format(new Date(event.date), "PPP", { locale: es })}</span>
                            </div>
                            {event.start_time && (
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span>
                                  {event.start_time} - {event.end_time}
                                </span>
                              </div>
                            )}
                            {event.location && (
                              <div className="flex items-center gap-1">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span>{event.location}</span>
                              </div>
                            )}
                            {event.workspace_name && (
                              <div className="flex items-center gap-1">
                                <Badge variant="outline">{event.workspace_name}</Badge>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => deleteEvent(event.id)} className="h-8 w-8">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CalendarIcon className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-2">No hay eventos para esta fecha</p>
                    <Button variant="outline" onClick={() => setShowAddEventDialog(true)}>
                      Añadir evento
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Todos los eventos</CardTitle>
              <CardDescription>Vista de lista de todos tus eventos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {events.length > 0 ? (
                  events
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map((event) => (
                      <div
                        key={event.id}
                        className="flex items-start space-x-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                      >
                        <div className={`w-1 self-stretch rounded-full ${getEventTypeColor(event.type)}`}></div>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{event.title}</h3>
                            {getEventTypeBadge(event.type)}
                          </div>
                          <p className="text-sm text-muted-foreground">{event.description}</p>
                          <div className="flex flex-wrap gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                              <span>{format(new Date(event.date), "PPP", { locale: es })}</span>
                            </div>
                            {event.start_time && (
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span>
                                  {event.start_time} - {event.end_time}
                                </span>
                              </div>
                            )}
                            {event.location && (
                              <div className="flex items-center gap-1">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span>{event.location}</span>
                              </div>
                            )}
                            {event.workspace_name && (
                              <div className="flex items-center gap-1">
                                <Badge variant="outline">{event.workspace_name}</Badge>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => deleteEvent(event.id)} className="h-8 w-8">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CalendarIcon className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-2">No hay eventos</p>
                    <Button variant="outline" onClick={() => setShowAddEventDialog(true)}>
                      Añadir evento
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
