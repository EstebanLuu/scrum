import { DashboardOverview } from "@/components/dashboard/dashboard-overview"
import { TasksList } from "@/components/dashboard/tasks-list"
import { WorkspacesList } from "@/components/dashboard/workspaces-list"
import { PomodoroTimer } from "@/components/dashboard/pomodoro-timer"
import { UpcomingEvents } from "@/components/dashboard/upcoming-events"
import { WeeklyGoals } from "@/components/dashboard/weekly-goals"
import { MotivationalCard } from "@/components/dashboard/motivational-card"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <DashboardOverview />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <TasksList />
        <WorkspacesList />
        <UpcomingEvents />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <PomodoroTimer />
        <WeeklyGoals />
        <MotivationalCard />
      </div>
    </div>
  )
}
