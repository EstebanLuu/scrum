import { WorkspaceHeader } from "@/components/workspaces/workspace-header"
import { WorkspaceTabs } from "@/components/workspaces/workspace-tabs"

export default function WorkspaceDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <WorkspaceHeader id={params.id} />
      <WorkspaceTabs id={params.id} />
    </div>
  )
}
