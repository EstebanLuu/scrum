"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, Plus, Star, Check, ExternalLink } from "lucide-react"

type Gadget = {
  id: string
  name: string
  description: string
  icon: string
  category: string
  installed: boolean
  featured: boolean
  developer: string
  rating: number
  price: string
}

export default function GadgetsPage() {
  const [gadgets, setGadgets] = useState<Gadget[]>([
    {
      id: "1",
      name: "Google Calendar",
      description: "Sincroniza tus eventos con Google Calendar",
      icon: "https://upload.wikimedia.org/wikipedia/commons/a/a5/Google_Calendar_icon_%282020%29.svg",
      category: "calendario",
      installed: true,
      featured: true,
      developer: "Google",
      rating: 4.8,
      price: "Gratis",
    },
    {
      id: "2",
      name: "Microsoft Teams",
      description: "Integración con Microsoft Teams para reuniones",
      icon: "https://upload.wikimedia.org/wikipedia/commons/c/c9/Microsoft_Office_Teams_%282018%E2%80%93present%29.svg",
      category: "comunicación",
      installed: false,
      featured: true,
      developer: "Microsoft",
      rating: 4.5,
      price: "Gratis",
    },
    {
      id: "3",
      name: "Trello",
      description: "Conecta tus tableros de Trello con Gestini",
      icon: "https://upload.wikimedia.org/wikipedia/en/8/8c/Trello_logo.svg",
      category: "productividad",
      installed: false,
      featured: true,
      developer: "Atlassian",
      rating: 4.7,
      price: "Freemium",
    },
    {
      id: "4",
      name: "Slack",
      description: "Recibe notificaciones en tus canales de Slack",
      icon: "https://upload.wikimedia.org/wikipedia/commons/d/d5/Slack_icon_2019.svg",
      category: "comunicación",
      installed: true,
      featured: false,
      developer: "Slack Technologies",
      rating: 4.6,
      price: "Freemium",
    },
    {
      id: "5",
      name: "GitHub",
      description: "Integra tus repositorios y issues de GitHub",
      icon: "https://upload.wikimedia.org/wikipedia/commons/9/91/Octicons-mark-github.svg",
      category: "desarrollo",
      installed: false,
      featured: false,
      developer: "GitHub",
      rating: 4.9,
      price: "Gratis",
    },
    {
      id: "6",
      name: "Dropbox",
      description: "Accede a tus archivos de Dropbox directamente",
      icon: "https://upload.wikimedia.org/wikipedia/commons/7/74/Dropbox_logo.svg",
      category: "almacenamiento",
      installed: false,
      featured: false,
      developer: "Dropbox, Inc.",
      rating: 4.4,
      price: "Freemium",
    },
    {
      id: "7",
      name: "Zoom",
      description: "Programa y gestiona reuniones de Zoom",
      icon: "https://upload.wikimedia.org/wikipedia/commons/9/9a/Zoom_logo.svg",
      category: "comunicación",
      installed: false,
      featured: true,
      developer: "Zoom Video Communications",
      rating: 4.3,
      price: "Freemium",
    },
    {
      id: "8",
      name: "Google Drive",
      description: "Accede a tus documentos de Google Drive",
      icon: "https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg",
      category: "almacenamiento",
      installed: false,
      featured: false,
      developer: "Google",
      rating: 4.7,
      price: "Gratis",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  // Obtener todas las categorías únicas
  const allCategories = Array.from(new Set(gadgets.map((gadget) => gadget.category)))

  // Filtrar gadgets
  const filteredGadgets = gadgets.filter((gadget) => {
    // Filtrar por término de búsqueda
    const matchesSearch =
      searchTerm === "" ||
      gadget.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      gadget.description.toLowerCase().includes(searchTerm.toLowerCase())

    // Filtrar por categoría
    const matchesCategory = selectedCategory === null || gadget.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  // Separar gadgets instalados y disponibles
  const installedGadgets = filteredGadgets.filter((gadget) => gadget.installed)
  const availableGadgets = filteredGadgets.filter((gadget) => !gadget.installed)

  const toggleInstallation = (gadgetId: string) => {
    setGadgets(gadgets.map((gadget) => (gadget.id === gadgetId ? { ...gadget, installed: !gadget.installed } : gadget)))

    const gadget = gadgets.find((g) => g.id === gadgetId)
    if (gadget) {
      toast({
        title: gadget.installed ? "Gadget desinstalado" : "Gadget instalado",
        description: gadget.installed
          ? `${gadget.name} ha sido desinstalado correctamente.`
          : `${gadget.name} ha sido instalado correctamente.`,
      })
    }
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Toaster />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gadgets</h1>
          <p className="text-muted-foreground">Extiende la funcionalidad de Gestini con integraciones.</p>
        </div>

        <Button className="gap-1" asChild>
          <a href="https://gestini.dev/marketplace" target="_blank" rel="noopener noreferrer">
            <ExternalLink className="h-4 w-4" />
            Visitar Marketplace
          </a>
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-64 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar gadgets..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Categorías</h3>
                <div className="space-y-1">
                  <Button
                    variant={selectedCategory === null ? "default" : "outline"}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setSelectedCategory(null)}
                  >
                    Todas
                  </Button>
                  {allCategories.map((category) => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estadísticas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Total de gadgets:</span>
                  <span className="font-medium">{gadgets.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Instalados:</span>
                  <span className="font-medium">{gadgets.filter((g) => g.installed).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Categorías:</span>
                  <span className="font-medium">{allCategories.length}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <Tabs defaultValue="installed" className="space-y-4">
            <TabsList>
              <TabsTrigger value="installed">Instalados ({installedGadgets.length})</TabsTrigger>
              <TabsTrigger value="available">Disponibles ({availableGadgets.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="installed">
              {installedGadgets.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {installedGadgets.map((gadget) => (
                    <Card key={gadget.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-3">
                          <img
                            src={gadget.icon || "/placeholder.svg"}
                            alt={gadget.name}
                            className="h-10 w-10 object-contain"
                          />
                          <div>
                            <CardTitle className="text-lg flex items-center gap-1">
                              {gadget.name}
                              {gadget.featured && <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />}
                            </CardTitle>
                            <CardDescription>{gadget.developer}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <p className="text-sm">{gadget.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <Badge variant="outline">{gadget.category}</Badge>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm">{gadget.rating}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <span className="text-sm text-muted-foreground">{gadget.price}</span>
                        <Button variant="outline" size="sm" onClick={() => toggleInstallation(gadget.id)}>
                          Desinstalar
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Plus className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-2">No tienes gadgets instalados</p>
                  <Button variant="outline" onClick={() => document.querySelector('[data-value="available"]')?.click()}>
                    Explorar gadgets
                  </Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="available">
              {availableGadgets.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {availableGadgets.map((gadget) => (
                    <Card key={gadget.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-3">
                          <img
                            src={gadget.icon || "/placeholder.svg"}
                            alt={gadget.name}
                            className="h-10 w-10 object-contain"
                          />
                          <div>
                            <CardTitle className="text-lg flex items-center gap-1">
                              {gadget.name}
                              {gadget.featured && <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />}
                            </CardTitle>
                            <CardDescription>{gadget.developer}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <p className="text-sm">{gadget.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <Badge variant="outline">{gadget.category}</Badge>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm">{gadget.rating}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <span className="text-sm text-muted-foreground">{gadget.price}</span>
                        <Button variant="default" size="sm" onClick={() => toggleInstallation(gadget.id)}>
                          <Plus className="h-4 w-4 mr-1" />
                          Instalar
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Check className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-2">Todos los gadgets están instalados</p>
                  <Button variant="outline" asChild>
                    <a href="https://gestini.dev/marketplace" target="_blank" rel="noopener noreferrer">
                      Explorar más gadgets
                    </a>
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
