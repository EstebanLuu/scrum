"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"

type Workspace = Tables<"workspaces"> & {
  tasksCount?: number
}

interface EditWorkspaceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  workspace: Workspace | null
  onWorkspaceUpdated: () => void
}

export function EditWorkspaceDialog({ open, onOpenChange, workspace, onWorkspaceUpdated }: EditWorkspaceDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [editedWorkspace, setEditedWorkspace] = useState<Partial<Workspace>>({})

  // Cargar datos del espacio cuando se abre el diálogo
  useEffect(() => {
    if (workspace && open) {
      setEditedWorkspace({
        name: workspace.name,
        description: workspace.description,
        type: workspace.type,
        color: workspace.color,
      })
    }
  }, [workspace, open])

  const handleSave = async () => {
    if (!workspace || !editedWorkspace.name) {
      toast({
        title: "Error",
        description: "El nombre del espacio es obligatorio.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Actualizar el espacio de trabajo
      const { error } = await supabase
        .from("workspaces")
        .update({
          name: editedWorkspace.name,
          description: editedWorkspace.description,
          type: editedWorkspace.type,
          color: editedWorkspace.color,
          updated_at: new Date().toISOString(),
        })
        .eq("id", workspace.id)

      if (error) {
        throw error
      }

      toast({
        title: "Espacio actualizado",
        description: "El espacio de trabajo ha sido actualizado correctamente.",
      })

      onWorkspaceUpdated()
      onOpenChange(false)
    } catch (error: any) {
      console.error("Error al actualizar espacio:", error)
      toast({
        title: "Error",
        description: error.message || "Error al actualizar el espacio. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const colorOptions = [
    { value: "#4f46e5", label: "Índigo" },
    { value: "#0ea5e9", label: "Azul" },
    { value: "#10b981", label: "Verde" },
    { value: "#f59e0b", label: "Ámbar" },
    { value: "#ef4444", label: "Rojo" },
    { value: "#8b5cf6", label: "Violeta" },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Editar espacio</DialogTitle>
          <DialogDescription>Actualiza la información del espacio de trabajo.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Nombre</Label>
            <Input
              id="name"
              value={editedWorkspace.name || ""}
              onChange={(e) => setEditedWorkspace({ ...editedWorkspace, name: e.target.value })}
              placeholder="Ej: Mi Empresa, Universidad, etc."
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Descripción</Label>
            <Input
              id="description"
              value={editedWorkspace.description || ""}
              onChange={(e) => setEditedWorkspace({ ...editedWorkspace, description: e.target.value })}
              placeholder="Descripción del espacio de trabajo"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="type">Tipo</Label>
            <Select
              value={editedWorkspace.type || ""}
              onValueChange={(value) => setEditedWorkspace({ ...editedWorkspace, type: value })}
            >
              <SelectTrigger id="type">
                <SelectValue placeholder="Selecciona un tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="business">Empresa</SelectItem>
                <SelectItem value="education">Educación</SelectItem>
                <SelectItem value="personal">Personal</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="color">Color</Label>
            <Select
              value={editedWorkspace.color || ""}
              onValueChange={(value) => setEditedWorkspace({ ...editedWorkspace, color: value })}
            >
              <SelectTrigger id="color">
                <SelectValue placeholder="Selecciona un color" />
              </SelectTrigger>
              <SelectContent>
                {colorOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-full" style={{ backgroundColor: option.value }} />
                      <span>{option.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              "Guardar cambios"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
