"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Calendar, CheckCircle, Clock, Plus } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

type SprintTask = {
  id: string
  title: string
  completed: boolean
}

type Sprint = {
  id: string
  title: string
  startDate: Date
  endDate: Date
  tasks: SprintTask[]
  status: "active" | "completed" | "planned"
}

export function SprintsList({ workspaceId }: { workspaceId: string }) {
  const today = new Date()

  const [sprints, setSprints] = useState<Sprint[]>([
    {
      id: "1",
      title: "Sprint 1: Diseño de interfaz",
      startDate: new Date(2023, 10, 1),
      endDate: new Date(2023, 10, 14),
      status: "completed",
      tasks: [
        { id: "task-1", title: "Wireframes", completed: true },
        { id: "task-2", title: "Diseño de componentes", completed: true },
        { id: "task-3", title: "Prototipo interactivo", completed: true },
      ],
    },
    {
      id: "2",
      title: "Sprint 2: Desarrollo frontend",
      startDate: new Date(2023, 10, 15),
      endDate: new Date(2023, 10, 28),
      status: "active",
      tasks: [
        { id: "task-4", title: "Implementar componentes", completed: true },
        { id: "task-5", title: "Integrar API", completed: false },
        { id: "task-6", title: "Pruebas de usabilidad", completed: false },
      ],
    },
    {
      id: "3",
      title: "Sprint 3: Backend y despliegue",
      startDate: new Date(2023, 10, 29),
      endDate: new Date(2023, 11, 12),
      status: "planned",
      tasks: [
        { id: "task-7", title: "Configurar base de datos", completed: false },
        { id: "task-8", title: "Implementar autenticación", completed: false },
        { id: "task-9", title: "Despliegue en producción", completed: false },
      ],
    },
  ])

  const toggleTaskCompletion = (sprintId: string, taskId: string) => {
    setSprints(
      sprints.map((sprint) => {
        if (sprint.id === sprintId) {
          const updatedTasks = sprint.tasks.map((task) =>
            task.id === taskId ? { ...task, completed: !task.completed } : task,
          )

          // Actualizar estado del sprint si todas las tareas están completadas
          const allCompleted = updatedTasks.every((task) => task.completed)

          return {
            ...sprint,
            tasks: updatedTasks,
            status: allCompleted ? "completed" : sprint.status,
          }
        }
        return sprint
      }),
    )

    toast({
      title: "Tarea actualizada",
      description: "El estado de la tarea ha sido actualizado.",
    })
  }

  const getSprintProgress = (sprint: Sprint) => {
    if (sprint.tasks.length === 0) return 0
    const completedTasks = sprint.tasks.filter((task) => task.completed).length
    return Math.round((completedTasks / sprint.tasks.length) * 100)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge>Activo</Badge>
      case "completed":
        return <Badge variant="secondary">Completado</Badge>
      case "planned":
        return <Badge variant="outline">Planificado</Badge>
      default:
        return null
    }
  }

  const formatDateRange = (startDate: Date, endDate: Date) => {
    return `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
  }

  return (
    <div className="space-y-4">
      <Toaster />
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium">Sprints</h2>
        <Button className="gap-1">
          <Plus className="h-4 w-4" />
          Nuevo sprint
        </Button>
      </div>

      <div className="space-y-6">
        {sprints.map((sprint) => {
          const progress = getSprintProgress(sprint)

          return (
            <Card key={sprint.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{sprint.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{formatDateRange(sprint.startDate, sprint.endDate)}</span>
                    </div>
                  </div>
                  {getStatusBadge(sprint.status)}
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Progreso</span>
                      <span className="text-sm">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Tareas</h4>
                    <div className="space-y-2">
                      {sprint.tasks.map((task) => (
                        <div key={task.id} className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => toggleTaskCompletion(sprint.id, task.id)}
                            >
                              <CheckCircle
                                className={`h-4 w-4 ${task.completed ? "text-primary" : "text-muted-foreground"}`}
                              />
                              <span className="sr-only">
                                {task.completed ? "Marcar como incompleta" : "Marcar como completada"}
                              </span>
                            </Button>
                            <span className={`text-sm ${task.completed ? "line-through text-muted-foreground" : ""}`}>
                              {task.title}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <div className="flex justify-between items-center w-full">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>
                      {sprint.status === "completed"
                        ? "Completado"
                        : sprint.status === "active"
                          ? `${Math.ceil((sprint.endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))} días restantes`
                          : `Comienza en ${Math.ceil((sprint.startDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))} días`}
                    </span>
                  </div>
                  <Button variant="outline" size="sm">
                    Ver detalles
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )
        })}
      </div>

      {sprints.length === 0 && (
        <div className="h-40 border border-dashed rounded-lg flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground">No hay sprints definidos</p>
            <Button variant="outline" className="mt-2">
              Crear sprint
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
