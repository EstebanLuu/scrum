"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Calendar, MoreHorizontal, Plus, Tag, Trash2, User, Filter } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type Task = {
  id: string
  title: string
  status: "pending" | "in-progress" | "completed"
  priority: "low" | "medium" | "high"
  dueDate: Date | null
  completed: boolean
  responsible: string | null
  sprint: string | null
}

type UserType = {
  id: string
  name: string
  avatar: string | null
  initials: string
}

export function TasksTable({ workspaceId }: { workspaceId: string }) {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Completar informe de ventas",
      status: "pending",
      priority: "high",
      dueDate: new Date(2023, 11, 15),
      completed: false,
      responsible: "user1",
      sprint: null,
    },
    {
      id: "2",
      title: "Revisar propuesta de marketing",
      status: "in-progress",
      priority: "medium",
      dueDate: new Date(2023, 11, 20),
      completed: false,
      responsible: "user2",
      sprint: "Sprint 1",
    },
    {
      id: "3",
      title: "Actualizar sitio web",
      status: "completed",
      priority: "low",
      dueDate: null,
      completed: true,
      responsible: null,
      sprint: null,
    },
    {
      id: "4",
      title: "Preparar presentación para cliente",
      status: "pending",
      priority: "high",
      dueDate: new Date(2023, 11, 10),
      completed: false,
      responsible: "user1",
      sprint: "Sprint 2",
    },
    {
      id: "5",
      title: "Reunión con equipo de desarrollo",
      status: "pending",
      priority: "medium",
      dueDate: new Date(2023, 11, 12),
      completed: false,
      responsible: "user3",
      sprint: null,
    },
  ])

  const users: UserType[] = [
    { id: "user1", name: "Ana García", avatar: null, initials: "AG" },
    { id: "user2", name: "Carlos López", avatar: null, initials: "CL" },
    { id: "user3", name: "María Rodríguez", avatar: null, initials: "MR" },
  ]

  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [showAddTaskDialog, setShowAddTaskDialog] = useState(false)
  const [newTask, setNewTask] = useState<Partial<Task>>({
    title: "",
    status: "pending",
    priority: "medium",
    dueDate: null,
    completed: false,
    responsible: null,
    sprint: null,
  })

  // Filtros
  const [filters, setFilters] = useState({
    responsible: "",
    priority: "",
    status: "",
    sprint: "",
  })
  const [showFilters, setShowFilters] = useState(false)

  // Configuración de sprints
  const [showSprintColumn, setShowSprintColumn] = useState(false)

  const toggleTaskCompletion = (taskId: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId
          ? {
              ...task,
              completed: !task.completed,
              status: !task.completed ? "completed" : "pending",
            }
          : task,
      ),
    )
  }

  const deleteTask = (taskId: string) => {
    setTasks(tasks.filter((task) => task.id !== taskId))
    toast({
      title: "Tarea eliminada",
      description: "La tarea ha sido eliminada correctamente.",
    })
  }

  const addTask = () => {
    if (!newTask.title?.trim()) return

    const task: Task = {
      id: Date.now().toString(),
      title: newTask.title,
      status: newTask.status as "pending" | "in-progress" | "completed",
      priority: newTask.priority as "low" | "medium" | "high",
      dueDate: newTask.dueDate,
      completed: newTask.status === "completed",
      responsible: newTask.responsible,
      sprint: showSprintColumn ? newTask.sprint : null,
    }

    setTasks([...tasks, task])
    setNewTask({
      title: "",
      status: "pending",
      priority: "medium",
      dueDate: null,
      completed: false,
      responsible: null,
      sprint: null,
    })
    setShowAddTaskDialog(false)
    toast({
      title: "Tarea añadida",
      description: "La tarea ha sido añadida correctamente.",
    })
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive">Alta</Badge>
      case "medium":
        return <Badge variant="outline">Media</Badge>
      case "low":
        return <Badge variant="secondary">Baja</Badge>
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline">Pendiente</Badge>
      case "in-progress":
        return <Badge variant="default">En progreso</Badge>
      case "completed":
        return <Badge variant="secondary">Completada</Badge>
      default:
        return null
    }
  }

  const getResponsibleUser = (userId: string | null) => {
    if (!userId) return null
    return users.find((user) => user.id === userId)
  }

  const getFilteredTasks = () => {
    return tasks.filter((task) => {
      if (filters.responsible && task.responsible !== filters.responsible) return false
      if (filters.priority && task.priority !== filters.priority) return false
      if (filters.status && task.status !== filters.status) return false
      if (filters.sprint && task.sprint !== filters.sprint) return false
      return true
    })
  }

  const resetFilters = () => {
    setFilters({
      responsible: "",
      priority: "",
      status: "",
      sprint: "",
    })
  }

  const filteredTasks = getFilteredTasks()

  // Obtener sprints únicos para el filtro
  const sprints = Array.from(new Set(tasks.filter((t) => t.sprint).map((t) => t.sprint))) as string[]

  return (
    <div className="space-y-4">
      <Toaster />
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="gap-1">
            <Filter className="h-4 w-4" />
            Filtros
            {(filters.responsible || filters.priority || filters.status || filters.sprint) && (
              <Badge variant="secondary" className="ml-1">
                {Object.values(filters).filter(Boolean).length}
              </Badge>
            )}
          </Button>

          <div className="flex items-center space-x-2">
            <Label htmlFor="show-sprint" className="text-sm">
              Sprint
            </Label>
            <Switch id="show-sprint" checked={showSprintColumn} onCheckedChange={setShowSprintColumn} />
          </div>

          {showFilters && (
            <div className="flex items-center space-x-2 flex-wrap gap-2 mt-2 w-full">
              <Select
                value={filters.responsible}
                onValueChange={(value) => setFilters({ ...filters, responsible: value })}
              >
                <SelectTrigger className="w-[150px] h-8">
                  <SelectValue placeholder="Responsable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filters.priority} onValueChange={(value) => setFilters({ ...filters, priority: value })}>
                <SelectTrigger className="w-[120px] h-8">
                  <SelectValue placeholder="Prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="low">Baja</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                <SelectTrigger className="w-[120px] h-8">
                  <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="in-progress">En progreso</SelectItem>
                  <SelectItem value="completed">Completada</SelectItem>
                </SelectContent>
              </Select>

              {showSprintColumn && sprints.length > 0 && (
                <Select value={filters.sprint} onValueChange={(value) => setFilters({ ...filters, sprint: value })}>
                  <SelectTrigger className="w-[120px] h-8">
                    <SelectValue placeholder="Sprint" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {sprints.map((sprint) => (
                      <SelectItem key={sprint} value={sprint}>
                        {sprint}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <Button variant="ghost" size="sm" onClick={resetFilters}>
                Limpiar
              </Button>
            </div>
          )}
        </div>

        <Dialog open={showAddTaskDialog} onOpenChange={setShowAddTaskDialog}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              Añadir tarea
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Añadir nueva tarea</DialogTitle>
              <DialogDescription>Crea una nueva tarea para este espacio de trabajo.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  placeholder="Título de la tarea"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="status">Estado</Label>
                  <Select
                    value={newTask.status}
                    onValueChange={(value) => setNewTask({ ...newTask, status: value as any })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pendiente</SelectItem>
                      <SelectItem value="in-progress">En progreso</SelectItem>
                      <SelectItem value="completed">Completada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="priority">Prioridad</Label>
                  <Select
                    value={newTask.priority}
                    onValueChange={(value) => setNewTask({ ...newTask, priority: value as any })}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Prioridad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Baja</SelectItem>
                      <SelectItem value="medium">Media</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="responsible">Responsable</Label>
                  <Select
                    value={newTask.responsible || ""}
                    onValueChange={(value) => setNewTask({ ...newTask, responsible: value || null })}
                  >
                    <SelectTrigger id="responsible">
                      <SelectValue placeholder="Responsable" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">Sin asignar</SelectItem>
                      {users.map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {showSprintColumn && (
                  <div className="grid gap-2">
                    <Label htmlFor="sprint">Sprint</Label>
                    <Select
                      value={newTask.sprint || ""}
                      onValueChange={(value) => setNewTask({ ...newTask, sprint: value || null })}
                    >
                      <SelectTrigger id="sprint">
                        <SelectValue placeholder="Sprint" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="null">Sin sprint</SelectItem>
                        <SelectItem value="Sprint 1">Sprint 1</SelectItem>
                        <SelectItem value="Sprint 2">Sprint 2</SelectItem>
                        <SelectItem value="Sprint 3">Sprint 3</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button onClick={addTask}>Añadir tarea</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12"></TableHead>
              <TableHead>Tarea</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Prioridad</TableHead>
              <TableHead>Responsable</TableHead>
              <TableHead>Fecha</TableHead>
              {showSprintColumn && <TableHead>Sprint</TableHead>}
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTasks.map((task) => {
              const responsible = getResponsibleUser(task.responsible)

              return (
                <TableRow key={task.id} className={task.completed ? "bg-muted/50" : ""}>
                  <TableCell className="py-2">
                    <Checkbox checked={task.completed} onCheckedChange={() => toggleTaskCompletion(task.id)} />
                  </TableCell>
                  <TableCell className={`py-2 ${task.completed ? "text-muted-foreground line-through" : ""}`}>
                    {task.title}
                  </TableCell>
                  <TableCell className="py-2">{getStatusBadge(task.status)}</TableCell>
                  <TableCell className="py-2">{getPriorityBadge(task.priority)}</TableCell>
                  <TableCell className="py-2">
                    {responsible ? (
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          {responsible.avatar && <AvatarImage src={responsible.avatar} alt={responsible.name} />}
                          <AvatarFallback>{responsible.initials}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs">{responsible.name}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">Sin asignar</span>
                    )}
                  </TableCell>
                  <TableCell className="py-2">
                    {task.dueDate ? (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs">{task.dueDate.toLocaleDateString()}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">Sin fecha</span>
                    )}
                  </TableCell>
                  {showSprintColumn && (
                    <TableCell className="py-2">
                      {task.sprint ? (
                        <Badge variant="outline" className="text-xs">
                          {task.sprint}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground text-xs">-</span>
                      )}
                    </TableCell>
                  )}
                  <TableCell className="py-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Acciones</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>Establecer fecha</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Tag className="mr-2 h-4 w-4" />
                          <span>Cambiar prioridad</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <User className="mr-2 h-4 w-4" />
                          <span>Asignar responsable</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => deleteTask(task.id)}>
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Eliminar</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      {filteredTasks.length === 0 && (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <p className="text-muted-foreground mb-2">No hay tareas que coincidan con los filtros</p>
          {(filters.responsible || filters.priority || filters.status || filters.sprint) && (
            <Button variant="outline" size="sm" onClick={resetFilters}>
              Limpiar filtros
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
