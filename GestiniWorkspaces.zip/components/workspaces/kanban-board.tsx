"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, MoreHorizontal, GripVertical, Filter, Loader2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"

type KanbanColumn = Tables<"kanban_columns"> & {
  cards: KanbanCard[]
}

type KanbanCard = Tables<"kanban_cards"> & {
  responsible?: {
    id: string
    name: string
    avatar_url: string | null
  } | null
}

type Contact = Tables<"contacts">

interface KanbanBoardProps {
  workspaceId: string
}

export function KanbanBoard({ workspaceId }: KanbanBoardProps) {
  const [columns, setColumns] = useState<KanbanColumn[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [contacts, setContacts] = useState<Contact[]>([])
  const [userId, setUserId] = useState<string | null>(null)
  const [showAddColumnDialog, setShowAddColumnDialog] = useState(false)
  const [newColumnTitle, setNewColumnTitle] = useState("")
  const [showAddCardDialog, setShowAddCardDialog] = useState(false)
  const [addCardToColumn, setAddCardToColumn] = useState<string | null>(null)
  const [newCard, setNewCard] = useState<Partial<KanbanCard>>({
    title: "",
    description: "",
    priority: "medium",
    responsible_id: null,
  })
  const [draggedCard, setDraggedCard] = useState<{ card: KanbanCard; columnId: string } | null>(null)
  const [draggedColumn, setDraggedColumn] = useState<KanbanColumn | null>(null)
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null)
  const [dragPreviewCard, setDragPreviewCard] = useState<{ card: KanbanCard; columnId: string } | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Filtros
  const [filters, setFilters] = useState({
    responsible: "",
    priority: "",
  })
  const [showFilters, setShowFilters] = useState(false)

  // Referencias para arrastrar y soltar
  const columnRefs = useRef<{ [key: string]: HTMLDivElement | null }>({})

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const supabase = getSupabaseClient()
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user) {
          setUserId(session.user.id)
          await fetchColumns()
          await fetchContacts()
        } else {
          window.location.href = "/login"
        }
      } catch (error) {
        console.error("Error al verificar la autenticación:", error)
        toast({
          title: "Error",
          description: "No se pudo verificar la autenticación. Por favor, inicia sesión de nuevo.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [workspaceId])

  const fetchColumns = async () => {
    try {
      const supabase = getSupabaseClient()

      // Obtener las columnas del espacio de trabajo
      const { data: columnsData, error: columnsError } = await supabase
        .from("kanban_columns")
        .select("*")
        .eq("workspace_id", workspaceId)
        .order("position")

      if (columnsError) {
        throw columnsError
      }

      // Si no hay columnas, crear las columnas predeterminadas
      if (columnsData.length === 0) {
        await createDefaultColumns()
        return
      }

      // Para cada columna, obtener sus tarjetas
      const columnsWithCards = await Promise.all(
        columnsData.map(async (column) => {
          const { data: cardsData, error: cardsError } = await supabase
            .from("kanban_cards")
            .select("*, responsible:contacts(id, name, avatar_url)")
            .eq("column_id", column.id)
            .order("position")

          if (cardsError) {
            throw cardsError
          }

          return {
            ...column,
            cards: cardsData,
          }
        }),
      )

      setColumns(columnsWithCards)
    } catch (error) {
      console.error("Error al obtener columnas:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar las columnas. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const createDefaultColumns = async () => {
    try {
      const supabase = getSupabaseClient()

      // Crear columnas predeterminadas
      const defaultColumns = [
        { title: "Por hacer", position: 0 },
        { title: "En progreso", position: 1 },
        { title: "Completado", position: 2 },
      ]

      for (let i = 0; i < defaultColumns.length; i++) {
        const { error } = await supabase.from("kanban_columns").insert({
          title: defaultColumns[i].title,
          position: defaultColumns[i].position,
          workspace_id: workspaceId,
        })

        if (error) {
          throw error
        }
      }

      // Volver a cargar las columnas
      await fetchColumns()
    } catch (error) {
      console.error("Error al crear columnas predeterminadas:", error)
      toast({
        title: "Error",
        description: "No se pudieron crear las columnas predeterminadas. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const fetchContacts = async () => {
    try {
      const supabase = getSupabaseClient()

      // Obtener los contactos del usuario
      const { data, error } = await supabase.from("contacts").select("*").order("name")

      if (error) {
        throw error
      }

      setContacts(data)
    } catch (error) {
      console.error("Error al obtener contactos:", error)
    }
  }

  const addColumn = async () => {
    if (!newColumnTitle.trim()) {
      toast({
        title: "Error",
        description: "El título de la columna no puede estar vacío.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const supabase = getSupabaseClient()

      // Obtener la posición más alta actual
      const maxPosition = columns.reduce((max, column) => Math.max(max, column.position), -1)

      // Crear la nueva columna
      const { error } = await supabase.from("kanban_columns").insert({
        title: newColumnTitle,
        position: maxPosition + 1,
        workspace_id: workspaceId,
      })

      if (error) {
        throw error
      }

      // Actualizar las columnas
      await fetchColumns()

      setNewColumnTitle("")
      setShowAddColumnDialog(false)

      toast({
        title: "Columna añadida",
        description: `La columna "${newColumnTitle}" ha sido añadida.`,
      })
    } catch (error: any) {
      console.error("Error al añadir columna:", error)
      toast({
        title: "Error",
        description: error.message || "Error al añadir la columna. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const removeColumn = async (columnId: string) => {
    // Verificar si la columna tiene tarjetas
    const column = columns.find((col) => col.id === columnId)
    if (column && column.cards.length > 0) {
      toast({
        title: "No se puede eliminar",
        description: "La columna contiene tarjetas. Mueve las tarjetas a otra columna primero.",
        variant: "destructive",
      })
      return
    }

    try {
      const supabase = getSupabaseClient()

      // Eliminar la columna
      const { error } = await supabase.from("kanban_columns").delete().eq("id", columnId)

      if (error) {
        throw error
      }

      // Actualizar las columnas
      await fetchColumns()

      toast({
        title: "Columna eliminada",
        description: "La columna ha sido eliminada.",
      })
    } catch (error: any) {
      console.error("Error al eliminar columna:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar la columna. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const addCard = async () => {
    if (!newCard.title?.trim() || !addCardToColumn) {
      toast({
        title: "Error",
        description: "El título de la tarjeta no puede estar vacío.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const supabase = getSupabaseClient()

      // Obtener la posición más alta actual en la columna
      const column = columns.find((col) => col.id === addCardToColumn)
      const maxPosition = column ? column.cards.reduce((max, card) => Math.max(max, card.position), -1) : -1

      // Crear la nueva tarjeta
      const { error } = await supabase.from("kanban_cards").insert({
        title: newCard.title,
        description: newCard.description || null,
        priority: newCard.priority as "low" | "medium" | "high",
        responsible_id: newCard.responsible_id || null,
        position: maxPosition + 1,
        column_id: addCardToColumn,
      })

      if (error) {
        throw error
      }

      // Actualizar las columnas
      await fetchColumns()

      setNewCard({
        title: "",
        description: "",
        priority: "medium",
        responsible_id: null,
      })
      setShowAddCardDialog(false)

      toast({
        title: "Tarjeta añadida",
        description: "La tarjeta ha sido añadida correctamente.",
      })
    } catch (error: any) {
      console.error("Error al añadir tarjeta:", error)
      toast({
        title: "Error",
        description: error.message || "Error al añadir la tarjeta. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const deleteCard = async (cardId: string) => {
    try {
      const supabase = getSupabaseClient()

      // Eliminar la tarjeta
      const { error } = await supabase.from("kanban_cards").delete().eq("id", cardId)

      if (error) {
        throw error
      }

      // Actualizar las columnas
      await fetchColumns()

      toast({
        title: "Tarjeta eliminada",
        description: "La tarjeta ha sido eliminada correctamente.",
      })
    } catch (error: any) {
      console.error("Error al eliminar tarjeta:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar la tarjeta. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const handleDragStart = (card: KanbanCard, columnId: string) => {
    setDraggedCard({ card, columnId })
  }

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault()
    if (draggedCard && draggedCard.columnId !== columnId) {
      setDragPreviewCard({ ...draggedCard, columnId })
    }
  }

  const handleDrop = async (columnId: string) => {
    if (!draggedCard) return

    // Si se suelta en la misma columna, no hacer nada
    if (draggedCard.columnId === columnId) {
      setDraggedCard(null)
      setDragPreviewCard(null)
      return
    }

    try {
      const supabase = getSupabaseClient()

      // Obtener la posición más alta actual en la columna de destino
      const targetColumn = columns.find((col) => col.id === columnId)
      const maxPosition = targetColumn ? targetColumn.cards.reduce((max, card) => Math.max(max, card.position), -1) : -1

      // Actualizar la tarjeta
      const { error } = await supabase
        .from("kanban_cards")
        .update({
          column_id: columnId,
          position: maxPosition + 1,
        })
        .eq("id", draggedCard.card.id)

      if (error) {
        throw error
      }

      // Actualizar las columnas
      await fetchColumns()

      toast({
        title: "Tarjeta movida",
        description: "La tarjeta ha sido movida correctamente.",
      })
    } catch (error: any) {
      console.error("Error al mover tarjeta:", error)
      toast({
        title: "Error",
        description: error.message || "Error al mover la tarjeta. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setDraggedCard(null)
      setDragPreviewCard(null)
    }
  }

  const handleColumnDragStart = (column: KanbanColumn) => {
    setDraggedColumn(column)
  }

  const handleColumnDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault()
    if (draggedColumn && draggedColumn.id !== columnId) {
      setDragOverColumn(columnId)
    }
  }

  const handleColumnDrop = async (columnId: string) => {
    if (!draggedColumn) return

    // Si se suelta en la misma posición, no hacer nada
    if (draggedColumn.id === columnId) {
      setDraggedColumn(null)
      setDragOverColumn(null)
      return
    }

    try {
      const supabase = getSupabaseClient()

      // Encontrar las columnas de origen y destino
      const sourceColumn = columns.find((col) => col.id === draggedColumn.id)
      const targetColumn = columns.find((col) => col.id === columnId)

      if (!sourceColumn || !targetColumn) {
        throw new Error("Columna no encontrada")
      }

      // Intercambiar posiciones
      const { error: error1 } = await supabase
        .from("kanban_columns")
        .update({ position: targetColumn.position })
        .eq("id", sourceColumn.id)

      if (error1) {
        throw error1
      }

      const { error: error2 } = await supabase
        .from("kanban_columns")
        .update({ position: sourceColumn.position })
        .eq("id", targetColumn.id)

      if (error2) {
        throw error2
      }

      // Actualizar las columnas
      await fetchColumns()

      toast({
        title: "Columna movida",
        description: "La columna ha sido movida correctamente.",
      })
    } catch (error: any) {
      console.error("Error al mover columna:", error)
      toast({
        title: "Error",
        description: error.message || "Error al mover la columna. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setDraggedColumn(null)
      setDragOverColumn(null)
    }
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive">Alta</Badge>
      case "medium":
        return <Badge variant="outline">Media</Badge>
      case "low":
        return <Badge variant="secondary">Baja</Badge>
      default:
        return null
    }
  }

  const getResponsibleUser = (userId: string | null) => {
    if (!userId) return null
    return contacts.find((contact) => contact.id === userId)
  }

  const getFilteredCards = (cards: KanbanCard[]) => {
    return cards.filter((card) => {
      if (filters.responsible && card.responsible_id !== filters.responsible) return false
      if (filters.priority && card.priority !== filters.priority) return false
      return true
    })
  }

  const resetFilters = () => {
    setFilters({
      responsible: "",
      priority: "",
    })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Toaster />

      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="gap-1">
            <Filter className="h-4 w-4" />
            Filtros
            {(filters.responsible || filters.priority) && (
              <Badge variant="secondary" className="ml-1">
                {Object.values(filters).filter(Boolean).length}
              </Badge>
            )}
          </Button>

          {showFilters && (
            <div className="flex items-center space-x-2">
              <Select
                value={filters.responsible}
                onValueChange={(value) => setFilters({ ...filters, responsible: value })}
              >
                <SelectTrigger className="w-[150px] h-8">
                  <SelectValue placeholder="Responsable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  {contacts.map((contact) => (
                    <SelectItem key={contact.id} value={contact.id}>
                      {contact.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filters.priority} onValueChange={(value) => setFilters({ ...filters, priority: value })}>
                <SelectTrigger className="w-[120px] h-8">
                  <SelectValue placeholder="Prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="low">Baja</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="ghost" size="sm" onClick={resetFilters}>
                Limpiar
              </Button>
            </div>
          )}
        </div>

        <Dialog open={showAddColumnDialog} onOpenChange={setShowAddColumnDialog}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              Añadir columna
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Añadir nueva columna</DialogTitle>
              <DialogDescription>Crea una nueva columna para organizar tus tareas.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="column-title">Título</Label>
                <Input
                  id="column-title"
                  value={newColumnTitle}
                  onChange={(e) => setNewColumnTitle(e.target.value)}
                  placeholder="Ej: En revisión, Bloqueado, etc."
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={addColumn} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Añadiendo...
                  </>
                ) : (
                  "Añadir columna"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 overflow-x-auto">
        {columns.map((column) => {
          const filteredCards = getFilteredCards(column.cards)
          const isColumnDraggedOver = dragOverColumn === column.id

          return (
            <div
              key={column.id}
              className={`space-y-4 min-w-[250px] ${
                isColumnDraggedOver ? "opacity-70 border-2 border-dashed border-primary rounded-md" : ""
              } ${draggedColumn?.id === column.id ? "opacity-50" : ""}`}
              ref={(el) => (columnRefs.current[column.id] = el)}
              draggable
              onDragStart={() => handleColumnDragStart(column)}
              onDragOver={(e) => handleColumnDragOver(e, column.id)}
              onDrop={() => handleColumnDrop(column.id)}
            >
              <div className="flex items-center justify-between">
                <h3 className="font-medium flex items-center">
                  {column.title} ({filteredCards.length})
                </h3>
                <div className="flex items-center space-x-1">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          setAddCardToColumn(column.id)
                          setShowAddCardDialog(true)
                        }}
                      >
                        <Plus className="h-4 w-4" />
                        <span className="sr-only">Añadir tarjeta</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Añadir nueva tarjeta</DialogTitle>
                        <DialogDescription>Crea una nueva tarjeta para la columna "{column.title}".</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="task-title">Título</Label>
                          <Input
                            id="task-title"
                            value={newCard.title}
                            onChange={(e) => setNewCard({ ...newCard, title: e.target.value })}
                            placeholder="Título de la tarjeta"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="task-description">Descripción</Label>
                          <Input
                            id="task-description"
                            value={newCard.description}
                            onChange={(e) => setNewCard({ ...newCard, description: e.target.value })}
                            placeholder="Descripción de la tarjeta"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="task-priority">Prioridad</Label>
                          <Select
                            value={newCard.priority}
                            onValueChange={(value) => setNewCard({ ...newCard, priority: value as any })}
                          >
                            <SelectTrigger id="task-priority">
                              <SelectValue placeholder="Prioridad" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">Baja</SelectItem>
                              <SelectItem value="medium">Media</SelectItem>
                              <SelectItem value="high">Alta</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="task-responsible">Responsable</Label>
                          <Select
                            value={newCard.responsible_id || ""}
                            onValueChange={(value) => setNewCard({ ...newCard, responsible_id: value || null })}
                          >
                            <SelectTrigger id="task-responsible">
                              <SelectValue placeholder="Responsable" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="">Sin asignar</SelectItem>
                              {contacts.map((contact) => (
                                <SelectItem key={contact.id} value={contact.id}>
                                  {contact.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={addCard} disabled={isSubmitting}>
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Añadiendo...
                            </>
                          ) : (
                            "Añadir tarjeta"
                          )}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Acciones</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => {
                          setNewColumnTitle(column.title)
                          setShowAddColumnDialog(true)
                        }}
                      >
                        Editar columna
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => removeColumn(column.id)}>Eliminar columna</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <div
                className="space-y-3 min-h-[200px] p-2 rounded-md border-2 border-dashed border-muted"
                style={{
                  backgroundColor:
                    draggedCard && column.id !== draggedCard.columnId ? "rgba(0, 0, 0, 0.03)" : "transparent",
                }}
                onDragOver={(e) => handleDragOver(e, column.id)}
                onDrop={() => handleDrop(column.id)}
              >
                {/* Mostrar vista previa de la tarjeta si se está arrastrando sobre esta columna */}
                {dragPreviewCard && dragPreviewCard.columnId === column.id && draggedCard && (
                  <Card className="opacity-50 border-2 border-dashed border-primary" style={{ height: "fit-content" }}>
                    <CardHeader className="p-3 pb-0 flex flex-row items-start justify-between space-y-0">
                      <div className="flex items-center gap-2">
                        <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                        <CardTitle className="text-sm font-medium">{draggedCard.card.title}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="p-3 pt-1">
                      <div className="flex justify-between items-center mt-2">
                        {getPriorityBadge(draggedCard.card.priority)}

                        {draggedCard.card.responsible && (
                          <Avatar className="h-6 w-6">
                            {draggedCard.card.responsible.avatar_url && (
                              <AvatarImage
                                src={draggedCard.card.responsible.avatar_url}
                                alt={draggedCard.card.responsible.name}
                              />
                            )}
                            <AvatarFallback>
                              {draggedCard.card.responsible.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .toUpperCase()
                                .substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {filteredCards.map((card) => {
                  const isDragging = draggedCard?.card.id === card.id

                  return (
                    <Card
                      key={card.id}
                      className={`cursor-move ${isDragging ? "opacity-50" : ""}`}
                      draggable
                      onDragStart={() => handleDragStart(card, column.id)}
                    >
                      <CardHeader className="p-3 pb-0 flex flex-row items-start justify-between space-y-0">
                        <div className="flex items-center gap-2">
                          <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                          <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Acciones</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>Editar</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => deleteCard(card.id)}>Eliminar</DropdownMenuItem>
                            {columns.map((col) => {
                              if (col.id !== column.id) {
                                return (
                                  <DropdownMenuItem
                                    key={col.id}
                                    onClick={() => {
                                      handleDragStart(card, column.id)
                                      handleDrop(col.id)
                                    }}
                                  >
                                    Mover a "{col.title}"
                                  </DropdownMenuItem>
                                )
                              }
                              return null
                            })}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </CardHeader>
                      <CardContent className="p-3 pt-1">
                        {card.description && <p className="text-xs text-muted-foreground mb-2">{card.description}</p>}
                        <div className="flex justify-between items-center mt-2">
                          {getPriorityBadge(card.priority)}

                          {card.responsible && (
                            <Avatar className="h-6 w-6">
                              {card.responsible.avatar_url && (
                                <AvatarImage src={card.responsible.avatar_url} alt={card.responsible.name} />
                              )}
                              <AvatarFallback>
                                {card.responsible.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .toUpperCase()
                                  .substring(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}

                {filteredCards.length === 0 && (
                  <div className="h-24 flex items-center justify-center text-sm text-muted-foreground">
                    {column.cards.length > 0 ? "No hay tarjetas que coincidan con los filtros" : "No hay tarjetas"}
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
