"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"

interface CreateWorkspaceDialogProps {
  children: React.ReactNode
  userId: string | null
  onWorkspaceCreated: () => void
}

export function CreateWorkspaceDialog({ children, userId, onWorkspaceCreated }: CreateWorkspaceDialogProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [type, setType] = useState("")
  const [color, setColor] = useState("#4f46e5")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !type || !userId) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Crear el espacio de trabajo
      const { data, error } = await supabase
        .from("workspaces")
        .insert({
          name,
          description,
          type,
          color,
          user_id: userId,
        })
        .select()
        .single()

      if (error) {
        throw error
      }

      toast({
        title: "Espacio creado",
        description: `El espacio "${name}" ha sido creado correctamente.`,
      })

      // Limpiar el formulario
      setName("")
      setDescription("")
      setType("")
      setColor("#4f46e5")
      setOpen(false)

      // Notificar que se ha creado un espacio
      onWorkspaceCreated()

      // Redirigir al nuevo espacio
      router.push(`/dashboard/workspaces/${data.id}`)
    } catch (error: any) {
      console.error("Error al crear espacio:", error)
      toast({
        title: "Error",
        description: error.message || "Error al crear el espacio. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const colorOptions = [
    { value: "#4f46e5", label: "Índigo" },
    { value: "#0ea5e9", label: "Azul" },
    { value: "#10b981", label: "Verde" },
    { value: "#f59e0b", label: "Ámbar" },
    { value: "#ef4444", label: "Rojo" },
    { value: "#8b5cf6", label: "Violeta" },
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Crear nuevo espacio</DialogTitle>
            <DialogDescription>
              Crea un nuevo espacio de trabajo para organizar tus tareas y proyectos.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nombre</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej: Mi Empresa, Universidad, etc."
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Descripción</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descripción del espacio de trabajo"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type">Tipo</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger id="type">
                  <SelectValue placeholder="Selecciona un tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="business">Empresa</SelectItem>
                  <SelectItem value="education">Educación</SelectItem>
                  <SelectItem value="personal">Personal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="color">Color</Label>
              <Select value={color} onValueChange={setColor}>
                <SelectTrigger id="color">
                  <SelectValue placeholder="Selecciona un color" />
                </SelectTrigger>
                <SelectContent>
                  {colorOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <div className="flex items-center gap-2">
                        <div className="h-4 w-4 rounded-full" style={{ backgroundColor: option.value }} />
                        <span>{option.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creando...
                </>
              ) : (
                "Crear espacio"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
