"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Edit, Trash2, Save, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Checkbox } from "@/components/ui/checkbox"

type GoalTask = {
  id: string
  title: string
  completed: boolean
}

type Goal = {
  id: string
  title: string
  description: string
  progress: number
  dueDate: Date | null
  tasks: GoalTask[]
}

export function GoalsList({ workspaceId }: { workspaceId: string }) {
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: "1",
      title: "Aumentar ventas en un 20%",
      description: "Incrementar las ventas del último trimestre en comparación con el anterior.",
      progress: 65,
      dueDate: new Date(2023, 11, 31),
      tasks: [
        { id: "task-1", title: "Analizar datos de ventas actuales", completed: true },
        { id: "task-2", title: "Desarrollar estrategia de marketing", completed: true },
        { id: "task-3", title: "Implementar campaña publicitaria", completed: false },
        { id: "task-4", title: "Evaluar resultados preliminares", completed: true },
      ],
    },
    {
      id: "2",
      title: "Lanzar nueva campaña de marketing",
      description: "Desarrollar y lanzar una nueva campaña para el producto principal.",
      progress: 30,
      dueDate: new Date(2023, 10, 15),
      tasks: [
        { id: "task-5", title: "Definir público objetivo", completed: true },
        { id: "task-6", title: "Crear materiales visuales", completed: false },
        { id: "task-7", title: "Preparar plan de medios", completed: false },
      ],
    },
    {
      id: "3",
      title: "Optimizar proceso de ventas",
      description: "Revisar y mejorar el proceso actual para aumentar la eficiencia.",
      progress: 100,
      dueDate: new Date(2023, 9, 30),
      tasks: [
        { id: "task-8", title: "Mapear proceso actual", completed: true },
        { id: "task-9", title: "Identificar cuellos de botella", completed: true },
        { id: "task-10", title: "Implementar mejoras", completed: true },
        { id: "task-11", title: "Capacitar al equipo", completed: true },
      ],
    },
  ])

  const [open, setOpen] = useState(false)
  const [newGoal, setNewGoal] = useState({
    title: "",
    description: "",
  })

  // Estado para edición
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null)
  const [editingGoal, setEditingGoal] = useState<Partial<Goal>>({})

  // Estado para tareas
  const [showTasksForGoal, setShowTasksForGoal] = useState<string | null>(null)
  const [newTaskTitle, setNewTaskTitle] = useState("")

  const handleAddGoal = () => {
    if (!newGoal.title) {
      toast({
        title: "Error",
        description: "El título del objetivo es obligatorio.",
        variant: "destructive",
      })
      return
    }

    const goal: Goal = {
      id: Date.now().toString(),
      title: newGoal.title,
      description: newGoal.description,
      progress: 0,
      dueDate: null,
      tasks: [],
    }

    setGoals([...goals, goal])
    setNewGoal({ title: "", description: "" })
    setOpen(false)

    toast({
      title: "Objetivo añadido",
      description: "El objetivo ha sido añadido correctamente.",
    })
  }

  const calculateProgress = (tasks: GoalTask[]): number => {
    if (tasks.length === 0) return 0
    const completedTasks = tasks.filter((task) => task.completed).length
    return Math.round((completedTasks / tasks.length) * 100)
  }

  const updateTaskStatus = (goalId: string, taskId: string, completed: boolean) => {
    const updatedGoals = goals.map((goal) => {
      if (goal.id === goalId) {
        const updatedTasks = goal.tasks.map((task) => (task.id === taskId ? { ...task, completed } : task))
        const newProgress = calculateProgress(updatedTasks)
        return { ...goal, tasks: updatedTasks, progress: newProgress }
      }
      return goal
    })

    setGoals(updatedGoals)
  }

  const addTaskToGoal = (goalId: string) => {
    if (!newTaskTitle.trim()) {
      toast({
        title: "Error",
        description: "El título de la tarea es obligatorio.",
        variant: "destructive",
      })
      return
    }

    const newTask: GoalTask = {
      id: `task-${Date.now()}`,
      title: newTaskTitle,
      completed: false,
    }

    const updatedGoals = goals.map((goal) => {
      if (goal.id === goalId) {
        const updatedTasks = [...goal.tasks, newTask]
        const newProgress = calculateProgress(updatedTasks)
        return { ...goal, tasks: updatedTasks, progress: newProgress }
      }
      return goal
    })

    setGoals(updatedGoals)
    setNewTaskTitle("")

    toast({
      title: "Tarea añadida",
      description: "La tarea ha sido añadida al objetivo.",
    })
  }

  const deleteTask = (goalId: string, taskId: string) => {
    const updatedGoals = goals.map((goal) => {
      if (goal.id === goalId) {
        const updatedTasks = goal.tasks.filter((task) => task.id !== taskId)
        const newProgress = calculateProgress(updatedTasks)
        return { ...goal, tasks: updatedTasks, progress: newProgress }
      }
      return goal
    })

    setGoals(updatedGoals)

    toast({
      title: "Tarea eliminada",
      description: "La tarea ha sido eliminada del objetivo.",
    })
  }

  const deleteGoal = (goalId: string) => {
    setGoals(goals.filter((goal) => goal.id !== goalId))

    toast({
      title: "Objetivo eliminado",
      description: "El objetivo ha sido eliminado correctamente.",
    })
  }

  const startEditing = (goal: Goal) => {
    setEditingGoalId(goal.id)
    setEditingGoal({
      title: goal.title,
      description: goal.description,
    })
  }

  const cancelEditing = () => {
    setEditingGoalId(null)
    setEditingGoal({})
  }

  const saveEditing = (goalId: string) => {
    if (!editingGoal.title) {
      toast({
        title: "Error",
        description: "El título del objetivo es obligatorio.",
        variant: "destructive",
      })
      return
    }

    setGoals(
      goals.map((goal) =>
        goal.id === goalId
          ? {
              ...goal,
              title: editingGoal.title || goal.title,
              description: editingGoal.description || goal.description,
            }
          : goal,
      ),
    )

    setEditingGoalId(null)
    setEditingGoal({})

    toast({
      title: "Objetivo actualizado",
      description: "El objetivo ha sido actualizado correctamente.",
    })
  }

  return (
    <div className="space-y-4">
      <Toaster />
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium">Objetivos</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              Nuevo objetivo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Añadir nuevo objetivo</DialogTitle>
              <DialogDescription>Crea un nuevo objetivo para tu espacio de trabajo.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  placeholder="Ej: Aumentar ventas en un 20%"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Descripción</Label>
                <Input
                  id="description"
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                  placeholder="Describe tu objetivo"
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleAddGoal}>Añadir objetivo</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {goals.map((goal) => (
          <Card key={goal.id}>
            <CardHeader className="pb-2">
              {editingGoalId === goal.id ? (
                <div className="space-y-2">
                  <Input
                    value={editingGoal.title}
                    onChange={(e) => setEditingGoal({ ...editingGoal, title: e.target.value })}
                    placeholder="Título del objetivo"
                    className="font-bold"
                  />
                </div>
              ) : (
                <CardTitle className="text-lg">{goal.title}</CardTitle>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {editingGoalId === goal.id ? (
                <div className="space-y-4">
                  <Input
                    value={editingGoal.description}
                    onChange={(e) => setEditingGoal({ ...editingGoal, description: e.target.value })}
                    placeholder="Descripción del objetivo"
                  />
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={cancelEditing}>
                      <X className="h-4 w-4 mr-1" />
                      Cancelar
                    </Button>
                    <Button size="sm" onClick={() => saveEditing(goal.id)}>
                      <Save className="h-4 w-4 mr-1" />
                      Guardar
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">{goal.description}</p>
              )}

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Progreso</span>
                  <span className="text-sm">{goal.progress}%</span>
                </div>
                <Progress value={goal.progress} className="h-2" />
              </div>

              {goal.dueDate && (
                <div className="text-sm text-muted-foreground">Fecha límite: {goal.dueDate.toLocaleDateString()}</div>
              )}

              <div className="flex justify-between items-center pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowTasksForGoal(showTasksForGoal === goal.id ? null : goal.id)}
                >
                  {showTasksForGoal === goal.id ? "Ocultar tareas" : "Ver tareas"}
                </Button>

                <div className="flex space-x-2">
                  {editingGoalId !== goal.id && (
                    <Button variant="ghost" size="icon" onClick={() => startEditing(goal)}>
                      <Edit className="h-4 w-4" />
                      <span className="sr-only">Editar</span>
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteGoal(goal.id)}
                    disabled={editingGoalId === goal.id}
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Eliminar</span>
                  </Button>
                </div>
              </div>

              {showTasksForGoal === goal.id && (
                <div className="mt-4 space-y-4 border-t pt-4">
                  <h4 className="text-sm font-medium">Tareas ({goal.tasks.length})</h4>

                  <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {goal.tasks.map((task) => (
                      <div key={task.id} className="flex items-start space-x-2">
                        <Checkbox
                          id={task.id}
                          checked={task.completed}
                          onCheckedChange={(checked) => updateTaskStatus(goal.id, task.id, checked === true)}
                        />
                        <div className="grid gap-1 flex-1">
                          <label
                            htmlFor={task.id}
                            className={`text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${
                              task.completed ? "line-through text-muted-foreground" : ""
                            }`}
                          >
                            {task.title}
                          </label>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => deleteTask(goal.id, task.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}

                    {goal.tasks.length === 0 && (
                      <p className="text-sm text-muted-foreground">No hay tareas para este objetivo.</p>
                    )}
                  </div>

                  <div className="flex space-x-2">
                    <Input
                      placeholder="Nueva tarea..."
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      className="text-sm"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          addTaskToGoal(goal.id)
                        }
                      }}
                    />
                    <Button size="sm" onClick={() => addTaskToGoal(goal.id)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {goals.length === 0 && (
        <div className="h-40 border border-dashed rounded-lg flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground">No hay objetivos definidos</p>
            <Button variant="outline" className="mt-2" onClick={() => setOpen(true)}>
              Añadir objetivo
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
