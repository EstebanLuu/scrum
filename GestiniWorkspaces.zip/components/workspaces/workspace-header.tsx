"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Briefcase, Calendar, Edit, MoreHorizontal, Users, UserPlus } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

type Workspace = {
  id: string
  name: string
  type: "business" | "education" | "personal"
  color: string
  tasksCount: number
  membersCount: number
}

type Member = {
  id: string
  name: string
  email: string
  role: "owner" | "editor" | "viewer"
  avatar: string | null
  initials: string
}

export function WorkspaceHeader({ id }: { id: string }) {
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [loading, setLoading] = useState(true)
  const [showMembersDialog, setShowMembersDialog] = useState(false)
  const [showInviteDialog, setShowInviteDialog] = useState(false)
  const [inviteEmail, setInviteEmail] = useState("")
  const [members, setMembers] = useState<Member[]>([])

  useEffect(() => {
    // Simulando carga de datos
    const loadWorkspace = () => {
      // Datos de ejemplo
      const workspaceData: Workspace = {
        id,
        name: id === "1" ? "Mi Empresa" : id === "2" ? "Universidad" : "Proyecto Personal",
        type: id === "1" ? "business" : id === "2" ? "education" : "personal",
        color: id === "1" ? "#4f46e5" : id === "2" ? "#0ea5e9" : "#10b981",
        tasksCount: id === "1" ? 12 : id === "2" ? 8 : 5,
        membersCount: id === "1" ? 5 : id === "2" ? 1 : 2,
      }

      const membersData: Member[] = [
        {
          id: "1",
          name: "Ana García",
          email: "ana@ejemplo.com",
          role: "owner",
          avatar: null,
          initials: "AG",
        },
      ]

      // Añadir miembros adicionales según el espacio
      if (id === "1") {
        membersData.push(
          {
            id: "2",
            name: "Carlos López",
            email: "carlos@ejemplo.com",
            role: "editor",
            avatar: null,
            initials: "CL",
          },
          {
            id: "3",
            name: "María Rodríguez",
            email: "maria@ejemplo.com",
            role: "editor",
            avatar: null,
            initials: "MR",
          },
          {
            id: "4",
            name: "Juan Pérez",
            email: "juan@ejemplo.com",
            role: "viewer",
            avatar: null,
            initials: "JP",
          },
          {
            id: "5",
            name: "Laura Sánchez",
            email: "laura@ejemplo.com",
            role: "viewer",
            avatar: null,
            initials: "LS",
          },
        )
      } else if (id === "3") {
        membersData.push({
          id: "2",
          name: "Carlos López",
          email: "carlos@ejemplo.com",
          role: "editor",
          avatar: null,
          initials: "CL",
        })
      }

      setWorkspace(workspaceData)
      setMembers(membersData)
      setLoading(false)
    }

    loadWorkspace()
  }, [id])

  const handleInviteMember = () => {
    if (!inviteEmail || !inviteEmail.includes("@")) {
      toast({
        title: "Error",
        description: "Por favor, introduce un email válido.",
        variant: "destructive",
      })
      return
    }

    // Simulando invitación
    toast({
      title: "Invitación enviada",
      description: `Se ha enviado una invitación a ${inviteEmail}.`,
    })

    setInviteEmail("")
    setShowInviteDialog(false)
  }

  const changeMemberRole = (memberId: string, newRole: "owner" | "editor" | "viewer") => {
    setMembers(members.map((member) => (member.id === memberId ? { ...member, role: newRole } : member)))

    toast({
      title: "Rol actualizado",
      description: "El rol del miembro ha sido actualizado.",
    })
  }

  const removeMember = (memberId: string) => {
    // No permitir eliminar al propietario
    const member = members.find((m) => m.id === memberId)
    if (member?.role === "owner") {
      toast({
        title: "No se puede eliminar",
        description: "No puedes eliminar al propietario del espacio.",
        variant: "destructive",
      })
      return
    }

    setMembers(members.filter((member) => member.id !== memberId))

    toast({
      title: "Miembro eliminado",
      description: "El miembro ha sido eliminado del espacio.",
    })
  }

  if (loading) {
    return <div>Cargando...</div>
  }

  if (!workspace) {
    return <div>No se encontró el espacio de trabajo</div>
  }

  return (
    <div className="flex flex-col space-y-4">
      <Toaster />
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div
            className="flex h-12 w-12 items-center justify-center rounded-lg"
            style={{ backgroundColor: workspace.color }}
          >
            {workspace.type === "business" ? (
              <Briefcase className="h-6 w-6 text-white" />
            ) : (
              <Calendar className="h-6 w-6 text-white" />
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold">{workspace.name}</h1>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
              <div className="flex items-center">
                <span>{workspace.tasksCount} tareas</span>
              </div>
              <Dialog open={showMembersDialog} onOpenChange={setShowMembersDialog}>
                <DialogTrigger asChild>
                  <Button variant="link" className="p-0 h-auto text-sm text-muted-foreground">
                    <Users className="mr-1 h-4 w-4" />
                    <span>
                      {workspace.membersCount} {workspace.membersCount === 1 ? "miembro" : "miembros"}
                    </span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Miembros del espacio</DialogTitle>
                    <DialogDescription>Gestiona los miembros de "{workspace.name}".</DialogDescription>
                  </DialogHeader>

                  <div className="py-4">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium">Miembros ({members.length})</h4>
                      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
                        <DialogTrigger asChild>
                          <Button size="sm" className="gap-1">
                            <UserPlus className="h-4 w-4" />
                            Invitar
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Invitar miembro</DialogTitle>
                            <DialogDescription>
                              Envía una invitación por email para unirse a este espacio.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                              <Label htmlFor="email">Email</Label>
                              <Input
                                id="email"
                                type="email"
                                placeholder="usuario@ejemplo.com"
                                value={inviteEmail}
                                onChange={(e) => setInviteEmail(e.target.value)}
                              />
                            </div>
                          </div>
                          <DialogFooter>
                            <Button onClick={handleInviteMember}>Enviar invitación</Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>

                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                      {members.map((member) => (
                        <div
                          key={member.id}
                          className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50"
                        >
                          <div className="flex items-center gap-3">
                            <Avatar>
                              {member.avatar && <AvatarImage src={member.avatar} alt={member.name} />}
                              <AvatarFallback>{member.initials}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{member.name}</p>
                              <p className="text-sm text-muted-foreground">{member.email}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm">
                                  {member.role === "owner"
                                    ? "Propietario"
                                    : member.role === "editor"
                                      ? "Editor"
                                      : "Visualizador"}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => changeMemberRole(member.id, "owner")}
                                  disabled={member.role === "owner"}
                                >
                                  Propietario
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => changeMemberRole(member.id, "editor")}
                                  disabled={member.role === "editor"}
                                >
                                  Editor
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => changeMemberRole(member.id, "viewer")}
                                  disabled={member.role === "viewer"}
                                >
                                  Visualizador
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => removeMember(member.id)}
                                  disabled={member.role === "owner"}
                                  className="text-destructive"
                                >
                                  Eliminar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Edit className="h-4 w-4" />
            <span className="hidden sm:inline">Editar</span>
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Más opciones</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowInviteDialog(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                Invitar miembros
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowMembersDialog(true)}>
                <Users className="mr-2 h-4 w-4" />
                Gestionar miembros
              </DropdownMenuItem>
              <DropdownMenuItem>Exportar tareas</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive">Eliminar espacio</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  )
}
