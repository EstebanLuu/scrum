"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Briefcase, GraduationCap, MoreHorizontal, Pencil, Trash2, Loader2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { getSupabaseClient } from "@/lib/supabase/client"
import { EditWorkspaceDialog } from "@/components/workspaces/edit-workspace-dialog"
import type { Tables } from "@/lib/types/database.types"
import { CreateWorkspaceDialog } from "@/components/workspaces/create-workspace-dialog"

type Workspace = Tables<"workspaces"> & {
  tasksCount: number
}

interface WorkspaceGridProps {
  userId: string | null
}

export function WorkspaceGrid({ userId }: WorkspaceGridProps) {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedWorkspace, setSelectedWorkspace] = useState<Workspace | null>(null)
  const [showEditDialog, setShowEditDialog] = useState(false)

  useEffect(() => {
    if (userId) {
      fetchWorkspaces()
    }
  }, [userId])

  const fetchWorkspaces = async () => {
    if (!userId) return

    setIsLoading(true)
    try {
      const supabase = getSupabaseClient()

      // Obtener los espacios de trabajo del usuario
      const { data: workspacesData, error: workspacesError } = await supabase
        .from("workspaces")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (workspacesError) {
        throw workspacesError
      }

      // Para cada espacio de trabajo, obtener el número de tareas
      const workspacesWithTaskCount = await Promise.all(
        workspacesData.map(async (workspace) => {
          const { count, error: tasksError } = await supabase
            .from("tasks")
            .select("*", { count: "exact", head: true })
            .eq("workspace_id", workspace.id)

          if (tasksError) {
            console.error("Error al obtener tareas:", tasksError)
            return { ...workspace, tasksCount: 0 }
          }

          return { ...workspace, tasksCount: count || 0 }
        }),
      )

      setWorkspaces(workspacesWithTaskCount)
    } catch (error) {
      console.error("Error al obtener espacios de trabajo:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los espacios de trabajo. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const deleteWorkspace = async (workspaceId: string) => {
    if (!userId) return

    try {
      const supabase = getSupabaseClient()

      // Verificar si hay tareas en el espacio de trabajo
      const { count, error: countError } = await supabase
        .from("tasks")
        .select("*", { count: "exact", head: true })
        .eq("workspace_id", workspaceId)

      if (countError) {
        throw countError
      }

      if (count && count > 0) {
        // Confirmar con el usuario si desea eliminar el espacio con tareas
        if (!window.confirm(`Este espacio contiene ${count} tareas. ¿Estás seguro de que deseas eliminarlo?`)) {
          return
        }
      }

      // Eliminar el espacio de trabajo
      const { error } = await supabase.from("workspaces").delete().eq("id", workspaceId).eq("user_id", userId) // Asegurarse de que el espacio pertenece al usuario

      if (error) {
        throw error
      }

      // Actualizar la lista de espacios
      await fetchWorkspaces()

      toast({
        title: "Espacio eliminado",
        description: "El espacio de trabajo ha sido eliminado correctamente.",
      })
    } catch (error: any) {
      console.error("Error al eliminar espacio:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar el espacio. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const editWorkspace = (workspace: Workspace) => {
    setSelectedWorkspace(workspace)
    setShowEditDialog(true)
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "business":
        return <Briefcase className="h-6 w-6 text-white" />
      case "education":
        return <GraduationCap className="h-6 w-6 text-white" />
      default:
        return <Briefcase className="h-6 w-6 text-white" />
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div>
      <Toaster />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {workspaces.map((workspace) => (
          <Card key={workspace.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <div className="h-24 flex items-center justify-center" style={{ backgroundColor: workspace.color }}>
                <div className="flex flex-col items-center">
                  {getIcon(workspace.type)}
                  <h3 className="mt-2 text-lg font-semibold text-white">{workspace.name}</h3>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-muted-foreground">{workspace.tasksCount} tareas</p>
                  <p className="text-xs text-muted-foreground">
                    Creado el {new Date(workspace.created_at).toLocaleDateString()}
                  </p>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Acciones</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => editWorkspace(workspace)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      <span>Editar</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => deleteWorkspace(workspace.id)}>
                      <Trash2 className="mr-2 h-4 w-4" />
                      <span>Eliminar</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              {workspace.description && <p className="text-sm mt-2 line-clamp-2">{workspace.description}</p>}
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Button asChild variant="outline" className="w-full">
                <Link href={`/dashboard/workspaces/${workspace.id}`}>Ver espacio</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {workspaces.length === 0 && (
        <div className="h-64 border border-dashed rounded-lg flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground">No tienes espacios de trabajo</p>
            <p className="text-sm text-muted-foreground mb-4">Crea tu primer espacio para comenzar</p>
            <CreateWorkspaceDialog userId={userId} onWorkspaceCreated={fetchWorkspaces}>
              <Button>Crear espacio</Button>
            </CreateWorkspaceDialog>
          </div>
        </div>
      )}

      {/* Diálogo de edición */}
      <EditWorkspaceDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        workspace={selectedWorkspace}
        onWorkspaceUpdated={fetchWorkspaces}
      />
    </div>
  )
}
