"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TasksTable } from "@/components/workspaces/tasks-table"
import { KanbanBoard } from "@/components/workspaces/kanban-board"
import { GoalsList } from "@/components/workspaces/goals-list"
import { SprintsList } from "@/components/workspaces/sprints-list"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function WorkspaceTabs({ id }: { id: string }) {
  const [activeTab, setActiveTab] = useState("tasks")
  const [showSprints, setShowSprints] = useState(false)
  const [showAdvancedFeatures, setShowAdvancedFeatures] = useState(false)

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex-1">
          <Tabs defaultValue="tasks" value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="tasks">Tareas</TabsTrigger>
              <TabsTrigger value="kanban">Kanban</TabsTrigger>
              <TabsTrigger value="goals">Objetivos</TabsTrigger>
              {showSprints && <TabsTrigger value="sprints">Sprints</TabsTrigger>}
            </TabsList>
          </Tabs>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Switch id="sprints-mode" checked={showSprints} onCheckedChange={setShowSprints} />
            <Label htmlFor="sprints-mode">Sprints</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="advanced-features" checked={showAdvancedFeatures} onCheckedChange={setShowAdvancedFeatures} />
            <Label htmlFor="advanced-features">Funciones avanzadas</Label>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsContent value="tasks" className="space-y-4">
          <TasksTable workspaceId={id} />

          {showAdvancedFeatures && (
            <div className="p-4 border rounded-md bg-muted/30">
              <h3 className="text-lg font-medium mb-2">Funciones avanzadas</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button className="p-2 border rounded-md text-left hover:bg-muted">Exportar tareas a CSV</button>
                <button className="p-2 border rounded-md text-left hover:bg-muted">Automatización de tareas</button>
                <button className="p-2 border rounded-md text-left hover:bg-muted">Reportes avanzados</button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="kanban" className="space-y-4">
          <KanbanBoard workspaceId={id} />
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <GoalsList workspaceId={id} />
        </TabsContent>

        {showSprints && (
          <TabsContent value="sprints" className="space-y-4">
            <SprintsList workspaceId={id} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
