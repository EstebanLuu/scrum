import { Briefcase, GraduationCap, ListTodo, FileText, Target, Timer } from "lucide-react"

export function LandingFeatures() {
  const features = [
    {
      icon: <Briefcase className="h-10 w-10 text-primary" />,
      title: "Crear espacios",
      description: "Empresas, carreras, materias y más. Organiza tu trabajo como prefieras.",
    },
    {
      icon: <ListTodo className="h-10 w-10 text-primary" />,
      title: "Gestión de tareas flexible",
      description: "Tabla editable con drag & drop para organizar tus tareas fácilmente.",
    },
    {
      icon: <FileText className="h-10 w-10 text-primary" />,
      title: "Documentos estilo Notion",
      description: "Crea y edita documentos con formato enriquecido y exporta a Word.",
    },
    {
      icon: <Target className="h-10 w-10 text-primary" />,
      title: "Objetivos y sprints",
      description: "Visualiza tu progreso con barras de avance y organiza tus sprints.",
    },
    {
      icon: <Timer className="h-10 w-10 text-primary" />,
      title: "Cronómetro Pomodoro",
      description: "Mejora tu concentración con la técnica Pomodoro integrada.",
    },
    {
      icon: <GraduationCap className="h-10 w-10 text-primary" />,
      title: "Ideal para estudiantes",
      description: "Organiza tus materias, trabajos y exámenes en un solo lugar.",
    },
  ]

  return (
    <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Características principales</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Todo lo que necesitas para organizar tu trabajo y estudios en un solo lugar.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center space-y-2 rounded-lg border p-4 bg-background">
              {feature.icon}
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
