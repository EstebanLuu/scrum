import { Zap, Database, Users } from "lucide-react"

export function LandingBenefits() {
  const benefits = [
    {
      icon: <Zap className="h-12 w-12 text-primary" />,
      title: "Aumentá tu productividad",
      description:
        "Organiza tus tareas, establece objetivos claros y utiliza el cronómetro Pomodoro para maximizar tu concentración y eficiencia.",
    },
    {
      icon: <Database className="h-12 w-12 text-primary" />,
      title: "Toda la información en un solo lugar",
      description:
        "Deja de saltar entre aplicaciones. Gestini centraliza tus tareas, documentos, objetivos y cronogramas en una única plataforma.",
    },
    {
      icon: <Users className="h-12 w-12 text-primary" />,
      title: "Ideal para estudiantes y empresarios",
      description:
        "Diseñado para adaptarse a diferentes necesidades, ya sea que estés gestionando materias universitarias o proyectos empresariales.",
    },
  ]

  return (
    <section id="benefits" className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Beneficios para el usuario</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Descubre cómo Gestini puede transformar tu forma de trabajar y estudiar.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-3 mt-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex flex-col items-center space-y-4 rounded-lg p-4">
              {benefit.icon}
              <h3 className="text-xl font-bold">{benefit.title}</h3>
              <p className="text-gray-500 dark:text-gray-400 text-center">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
