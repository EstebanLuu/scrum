"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import Link from "next/link"

export function LandingHero() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !email.includes("@")) {
      toast({
        title: "Error",
        description: "Por favor ingresa un email válido",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulando envío a API
    setTimeout(() => {
      toast({
        title: "¡Gracias por registrarte!",
        description: "Te avisaremos cuando Gestini esté disponible.",
      })
      setEmail("")
      setIsLoading(false)
    }, 1000)
  }

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
      <Toaster />
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
              Todos tus espacios de trabajo, en un solo lugar.
            </h1>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Desde materias y carreras hasta empresas y proyectos, organizá tu día con Gestini.
            </p>
          </div>
          <div className="w-full max-w-sm space-y-2">
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
              <Input
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="max-w-lg flex-1"
              />
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Enviando..." : "Unirse a la lista"}
              </Button>
            </form>
            <p className="text-xs text-gray-500 dark:text-gray-400">Te avisaremos cuando Gestini esté disponible.</p>
          </div>
          <Button variant="outline" asChild className="mt-4">
            <Link href="/dashboard">Probar la demo</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
