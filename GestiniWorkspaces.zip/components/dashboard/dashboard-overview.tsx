import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Clock, ListTodo, Target } from "lucide-react"

export function DashboardOverview() {
  const stats = [
    {
      title: "Tareas pendientes",
      value: "5",
      description: "2 con vencimiento hoy",
      icon: <ListTodo className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "Tareas completadas",
      value: "12",
      description: "Esta semana",
      icon: <CheckCircle className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "Tiempo enfocado",
      value: "3h 25m",
      description: "Hoy",
      icon: <Clock className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "Objetivos completados",
      value: "2/5",
      description: "Esta semana",
      icon: <Target className="h-4 w-4 text-muted-foreground" />,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            {stat.icon}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
