"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Pause, Play, RotateCcw, Settings, Volume2, VolumeX } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

export function PomodoroTimer() {
  const [mode, setMode] = useState<"work" | "break">("work")
  const [isActive, setIsActive] = useState(false)
  const [workTime, setWorkTime] = useState(25) // minutos
  const [breakTime, setBreakTime] = useState(5) // minutos
  const [timeLeft, setTimeLeft] = useState(workTime * 60) // convertir a segundos
  const [progress, setProgress] = useState(100)
  const [showSettings, setShowSettings] = useState(false)
  const [soundEnabled, setSoundEnabled] = useState(true)

  const audioRef = useRef<HTMLAudioElement | null>(null)

  const totalTime = mode === "work" ? workTime * 60 : breakTime * 60

  useEffect(() => {
    // Crear elemento de audio
    if (!audioRef.current) {
      audioRef.current = new Audio("/alarm.mp3")
      audioRef.current.volume = 0.5
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    // Actualizar timeLeft cuando cambian los tiempos configurados
    if (!isActive) {
      setTimeLeft(mode === "work" ? workTime * 60 : breakTime * 60)
      setProgress(100)
    }
  }, [workTime, breakTime, mode, isActive])

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prevTime) => {
          const newTime = prevTime - 1
          setProgress((newTime / totalTime) * 100)
          return newTime
        })
      }, 1000)
    } else if (isActive && timeLeft === 0) {
      // Reproducir sonido cuando el tiempo llega a 0
      if (soundEnabled && audioRef.current) {
        audioRef.current.play()
      }

      // Mostrar notificación
      toast({
        title: mode === "work" ? "¡Tiempo de descanso!" : "¡Tiempo de trabajo!",
        description:
          mode === "work"
            ? `Has completado ${workTime} minutos de trabajo. Tómate un descanso.`
            : `Tu descanso de ${breakTime} minutos ha terminado. ¡Vuelve al trabajo!`,
      })

      // Cambiar de modo cuando el tiempo llega a 0
      if (mode === "work") {
        setMode("break")
        setTimeLeft(breakTime * 60) // tiempo de descanso en segundos
        setProgress(100)
      } else {
        setMode("work")
        setTimeLeft(workTime * 60) // tiempo de trabajo en segundos
        setProgress(100)
      }
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, timeLeft, mode, totalTime, workTime, breakTime, soundEnabled])

  const toggleTimer = () => {
    setIsActive(!isActive)
  }

  const resetTimer = () => {
    setIsActive(false)
    if (mode === "work") {
      setTimeLeft(workTime * 60)
    } else {
      setTimeLeft(breakTime * 60)
    }
    setProgress(100)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const saveSettings = () => {
    setShowSettings(false)
    resetTimer()
  }

  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <div>
          <CardTitle>Personal Timer</CardTitle>
          <CardDescription>{mode === "work" ? "Tiempo de trabajo" : "Tiempo de descanso"}</CardDescription>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? "Desactivar sonido" : "Activar sonido"}
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>

          <Dialog open={showSettings} onOpenChange={setShowSettings}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon">
                <Settings className="h-4 w-4" />
                <span className="sr-only">Configuración</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Configuración del timer</DialogTitle>
                <DialogDescription>Personaliza los tiempos de trabajo y descanso.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="work-time">Tiempo de trabajo (minutos)</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      id="work-time"
                      min={5}
                      max={60}
                      step={5}
                      value={[workTime]}
                      onValueChange={(value) => setWorkTime(value[0])}
                    />
                    <span className="w-12 text-center">{workTime}</span>
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="break-time">Tiempo de descanso (minutos)</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      id="break-time"
                      min={1}
                      max={30}
                      step={1}
                      value={[breakTime]}
                      onValueChange={(value) => setBreakTime(value[0])}
                    />
                    <span className="w-12 text-center">{breakTime}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="sound-enabled">Sonido al finalizar</Label>
                  <Switch id="sound-enabled" checked={soundEnabled} onCheckedChange={setSoundEnabled} />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={saveSettings}>Guardar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col items-center justify-center space-y-2">
          <div className="text-4xl font-bold">{formatTime(timeLeft)}</div>
          <Progress value={progress} className="h-2 w-full" />
        </div>

        <div className="flex justify-center space-x-2">
          <Button variant="outline" size="icon" onClick={toggleTimer}>
            {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button variant="outline" size="icon" onClick={resetTimer}>
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Sesiones hoy: 3</span>
          <span>Tiempo total: 1h 15m</span>
        </div>
      </CardContent>
    </Card>
  )
}
