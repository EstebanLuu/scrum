import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Briefcase, GraduationCap, Plus } from "lucide-react"
import Link from "next/link"

type Workspace = {
  id: string
  name: string
  type: "business" | "education"
  tasksCount: number
  color: string
}

export function WorkspacesList() {
  const workspaces: Workspace[] = [
    { id: "1", name: "Mi Empresa", type: "business", tasksCount: 12, color: "#4f46e5" },
    { id: "2", name: "Universidad", type: "education", tasksCount: 8, color: "#0ea5e9" },
    { id: "3", name: "Proyecto Personal", type: "business", tasksCount: 5, color: "#10b981" },
  ]

  return (
    <Card className="col-span-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Espacios activos</CardTitle>
          <CardDescription>{workspaces.length} espacios de trabajo</CardDescription>
        </div>
        <Button size="sm" variant="outline" className="h-8 gap-1">
          <Plus className="h-3.5 w-3.5" />
          <span>Crear</span>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {workspaces.map((workspace) => (
            <div key={workspace.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div
                  className="flex h-8 w-8 items-center justify-center rounded-full"
                  style={{ backgroundColor: workspace.color }}
                >
                  {workspace.type === "business" ? (
                    <Briefcase className="h-4 w-4 text-white" />
                  ) : (
                    <GraduationCap className="h-4 w-4 text-white" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium">{workspace.name}</p>
                  <p className="text-xs text-muted-foreground">{workspace.tasksCount} tareas</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" asChild>
                <Link href={`/dashboard/workspaces/${workspace.id}`}>
                  <ArrowRight className="h-4 w-4" />
                  <span className="sr-only">Ver espacio</span>
                </Link>
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
