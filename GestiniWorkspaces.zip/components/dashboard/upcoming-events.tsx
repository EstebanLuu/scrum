import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"

type Event = {
  id: string
  title: string
  date: Date
  workspace: string
}

export function UpcomingEvents() {
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)

  const nextWeek = new Date(today)
  nextWeek.setDate(nextWeek.getDate() + 5)

  const events: Event[] = [
    {
      id: "1",
      title: "Entrega de informe",
      date: tomorrow,
      workspace: "Mi Empresa",
    },
    {
      id: "2",
      title: "Examen parcial",
      date: nextWeek,
      workspace: "Universidad",
    },
    {
      id: "3",
      title: "Reunión con cliente",
      date: today,
      workspace: "Mi Empresa",
    },
  ]

  // Ordenar eventos por fecha
  const sortedEvents = [...events].sort((a, b) => a.date.getTime() - b.date.getTime())

  return (
    <Card className="col-span-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Próximos eventos</CardTitle>
          <CardDescription>Eventos y tareas con fecha</CardDescription>
        </div>
        <CalendarIcon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedEvents.map((event) => {
            const isToday = event.date.toDateString() === today.toDateString()

            return (
              <div key={event.id} className="flex items-start space-x-3">
                <div className="flex flex-col items-center">
                  <span className="text-xs font-medium">
                    {isToday ? "HOY" : format(event.date, "dd", { locale: es })}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {isToday ? format(event.date, "HH:mm") : format(event.date, "MMM", { locale: es })}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium">{event.title}</p>
                  <p className="text-xs text-muted-foreground">{event.workspace}</p>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
