import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Lightbulb } from "lucide-react"

export function MotivationalCard() {
  const quotes = [
    {
      text: "La productividad no es hacer más cosas, es hacer las cosas correctas.",
      author: "Peter Drucker",
    },
    {
      text: "El tiempo es lo único que no podemos recuperar. Úsalo sabiamente.",
      author: "Anónimo",
    },
    {
      text: "No se trata de tener tiempo, se trata de hacer tiempo.",
      author: "Anónimo",
    },
    {
      text: "La disciplina es el puente entre metas y logros.",
      author: "Jim Rohn",
    },
  ]

  // Seleccionar una cita aleatoria
  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)]

  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          Motivación
        </CardTitle>
        <CardDescription>Inspiración para tu día</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-sm italic">"{randomQuote.text}"</p>
          <p className="text-xs text-muted-foreground text-right">— {randomQuote.author}</p>
        </div>
      </CardContent>
    </Card>
  )
}
