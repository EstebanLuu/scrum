"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle2 } from "lucide-react"

type Goal = {
  id: string
  title: string
  progress: number
  completed: boolean
}

export function WeeklyGoals() {
  const goals: Goal[] = [
    { id: "1", title: "Completar informe trimestral", progress: 75, completed: false },
    { id: "2", title: "Estudiar para examen", progress: 50, completed: false },
    { id: "3", title: "Actualizar sitio web", progress: 100, completed: true },
    { id: "4", title: "Preparar presentación", progress: 30, completed: false },
  ]

  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle>Objetivos de la semana</CardTitle>
        <CardDescription>
          {goals.filter((g) => g.completed).length} de {goals.length} completados
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {goals.map((goal) => (
            <div key={goal.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {goal.completed && <CheckCircle2 className="h-4 w-4 text-primary" />}
                  <span className={`text-sm font-medium ${goal.completed ? "text-muted-foreground line-through" : ""}`}>
                    {goal.title}
                  </span>
                </div>
                <span className="text-xs font-medium">{goal.progress}%</span>
              </div>
              <Progress value={goal.progress} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
