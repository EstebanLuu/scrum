"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

type Task = {
  id: string
  title: string
  completed: boolean
  workspace: string
}

export function TasksList() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", title: "Completar informe de ventas", completed: false, workspace: "Empresa" },
    { id: "2", title: "Estudiar para examen de matemáticas", completed: false, workspace: "Universidad" },
    { id: "3", title: "Preparar presentación", completed: true, workspace: "Empresa" },
    { id: "4", title: "Enviar correo a cliente", completed: false, workspace: "Empresa" },
    { id: "5", title: "Leer capítulo 5", completed: true, workspace: "Universidad" },
  ])

  const toggleTaskCompletion = (taskId: string) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
  }

  const pendingTasks = tasks.filter((task) => !task.completed)

  return (
    <Card className="col-span-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Tareas pendientes</CardTitle>
          <CardDescription>{pendingTasks.length} tareas por completar</CardDescription>
        </div>
        <Button size="sm" variant="outline" className="h-8 gap-1">
          <Plus className="h-3.5 w-3.5" />
          <span>Añadir</span>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pendingTasks.length > 0 ? (
            pendingTasks.map((task) => (
              <div key={task.id} className="flex items-start space-x-2">
                <Checkbox
                  id={`task-${task.id}`}
                  checked={task.completed}
                  onCheckedChange={() => toggleTaskCompletion(task.id)}
                />
                <div className="grid gap-1">
                  <label
                    htmlFor={`task-${task.id}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {task.title}
                  </label>
                  <p className="text-xs text-muted-foreground">{task.workspace}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">No hay tareas pendientes.</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
