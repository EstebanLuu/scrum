"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"

interface CreateDocumentDialogProps {
  children: React.ReactNode
  userId: string | null
  onDocumentCreated: () => void
  parentId?: string | null
}

export function CreateDocumentDialog({
  children,
  userId,
  onDocumentCreated,
  parentId = null,
}: CreateDocumentDialogProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [type, setType] = useState("document")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !userId) {
      toast({
        title: "Error",
        description: "Por favor ingresa un nombre",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Crear el documento o carpeta
      const { data, error } = await supabase
        .from("documents")
        .insert({
          title: name,
          content: type === "document" ? "" : null,
          type,
          parent_id: parentId,
          user_id: userId,
        })
        .select()
        .single()

      if (error) {
        throw error
      }

      toast({
        title: type === "document" ? "Documento creado" : "Carpeta creada",
        description: `"${name}" ha sido creado correctamente.`,
      })

      // Limpiar el formulario
      setName("")
      setType("document")
      setOpen(false)

      // Notificar que se ha creado un documento
      onDocumentCreated()

      // Si es un documento, redirigir al editor
      if (type === "document") {
        router.push(`/dashboard/documents/${data.id}`)
      }
    } catch (error: any) {
      console.error("Error al crear documento:", error)
      toast({
        title: "Error",
        description: error.message || "Error al crear el documento. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Crear nuevo</DialogTitle>
            <DialogDescription>Crea un nuevo documento o carpeta para organizar tu trabajo.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="type">Tipo</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger id="type">
                  <SelectValue placeholder="Selecciona un tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="document">Documento</SelectItem>
                  <SelectItem value="folder">Carpeta</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="name">Nombre</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={type === "document" ? "Mi documento" : "Mi carpeta"}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creando...
                </>
              ) : (
                "Crear"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
