"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"

type Document = Tables<"documents">

interface EditDocumentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  document: Document | null
  onDocumentUpdated: () => void
}

export function EditDocumentDialog({ open, onOpenChange, document, onDocumentUpdated }: EditDocumentDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [title, setTitle] = useState("")

  // Cargar datos del documento cuando se abre el diálogo
  useEffect(() => {
    if (document && open) {
      setTitle(document.title)
    }
  }, [document, open])

  const handleSave = async () => {
    if (!document || !title.trim()) {
      toast({
        title: "Error",
        description: "El título es obligatorio.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Actualizar el documento
      const { error } = await supabase
        .from("documents")
        .update({
          title,
          updated_at: new Date().toISOString(),
        })
        .eq("id", document.id)

      if (error) {
        throw error
      }

      toast({
        title: "Documento actualizado",
        description: "El documento ha sido actualizado correctamente.",
      })

      onDocumentUpdated()
      onOpenChange(false)
    } catch (error: any) {
      console.error("Error al actualizar documento:", error)
      toast({
        title: "Error",
        description: error.message || "Error al actualizar el documento. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Renombrar {document?.type === "folder" ? "carpeta" : "documento"}</DialogTitle>
          <DialogDescription>
            Actualiza el nombre de {document?.type === "folder" ? "la carpeta" : "el documento"}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="title">Título</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={document?.type === "folder" ? "Mi carpeta" : "Mi documento"}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              "Guardar cambios"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
