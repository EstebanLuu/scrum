"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, File, FileText, Folder, MoreHorizontal, Pencil, Trash2, Loader2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { getSupabaseClient } from "@/lib/supabase/client"
import { EditDocumentDialog } from "@/components/documents/edit-document-dialog"
import type { Tables } from "@/lib/types/database.types"

type Document = Tables<"documents">

interface DocumentsExplorerProps {
  userId: string | null
}

export function DocumentsExplorer({ userId }: DocumentsExplorerProps) {
  const router = useRouter()
  const [items, setItems] = useState<Document[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentFolder, setCurrentFolder] = useState<string | null>(null)
  const [breadcrumbs, setBreadcrumbs] = useState<{ id: string | null; name: string }[]>([
    { id: null, name: "Documentos" },
  ])
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null)
  const [showEditDialog, setShowEditDialog] = useState(false)

  useEffect(() => {
    if (userId) {
      fetchDocuments()
    }
  }, [userId, currentFolder])

  const fetchDocuments = async () => {
    if (!userId) return

    setIsLoading(true)
    try {
      const supabase = getSupabaseClient()

      // Obtener los documentos del usuario en la carpeta actual
      const { data, error } = await supabase
        .from("documents")
        .select("*")
        .eq("user_id", userId)
        .eq("parent_id", currentFolder)
        .order("type", { ascending: false }) // Carpetas primero
        .order("title")

      if (error) {
        throw error
      }

      setItems(data)
    } catch (error) {
      console.error("Error al obtener documentos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los documentos. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const navigateToFolder = async (folderId: string | null, folderName: string) => {
    setCurrentFolder(folderId)

    if (folderId === null) {
      // Volver a la raíz
      setBreadcrumbs([{ id: null, name: "Documentos" }])
    } else {
      // Navegar a una carpeta
      const newBreadcrumbs = [...breadcrumbs]

      // Si ya existe en las migas de pan, cortar hasta ese punto
      const existingIndex = newBreadcrumbs.findIndex((b) => b.id === folderId)
      if (existingIndex !== -1) {
        setBreadcrumbs(newBreadcrumbs.slice(0, existingIndex + 1))
      } else {
        // Añadir nueva miga de pan
        setBreadcrumbs([...newBreadcrumbs, { id: folderId, name: folderName }])
      }
    }
  }

  const openDocument = (documentId: string) => {
    // Navegar al editor de documentos
    router.push(`/dashboard/documents/${documentId}`)
  }

  const deleteItem = async (itemId: string) => {
    if (!userId) return

    try {
      const supabase = getSupabaseClient()

      // Verificar si es una carpeta y tiene elementos
      if (items.find((item) => item.id === itemId)?.type === "folder") {
        const { count, error: countError } = await supabase
          .from("documents")
          .select("*", { count: "exact", head: true })
          .eq("parent_id", itemId)

        if (countError) {
          throw countError
        }

        if (count && count > 0) {
          // Confirmar con el usuario si desea eliminar la carpeta con contenido
          if (
            !window.confirm(
              `Esta carpeta contiene ${count} elemento${count > 1 ? "s" : ""}. ¿Estás seguro de que deseas eliminarla?`,
            )
          ) {
            return
          }
        }
      }

      // Eliminar el elemento
      const { error } = await supabase.from("documents").delete().eq("id", itemId).eq("user_id", userId)

      if (error) {
        throw error
      }

      // Actualizar la lista de documentos
      await fetchDocuments()

      toast({
        title: "Elemento eliminado",
        description: "El elemento ha sido eliminado correctamente.",
      })
    } catch (error: any) {
      console.error("Error al eliminar elemento:", error)
      toast({
        title: "Error",
        description: error.message || "Error al eliminar el elemento. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    }
  }

  const editItem = (item: Document) => {
    setSelectedDocument(item)
    setShowEditDialog(true)
  }

  // Filtrar elementos según la carpeta actual
  const currentItems = items.filter((item) => item.parent_id === currentFolder)

  if (isLoading && items.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Toaster />

      {/* Breadcrumbs */}
      <nav className="flex items-center space-x-1 text-sm">
        {breadcrumbs.map((crumb, index) => (
          <div key={index} className="flex items-center">
            {index > 0 && <ChevronRight className="h-4 w-4 mx-1 text-muted-foreground" />}
            <Button
              variant="link"
              className="p-0 h-auto font-medium"
              onClick={() => navigateToFolder(crumb.id, crumb.name)}
            >
              {crumb.name}
            </Button>
          </div>
        ))}
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {currentItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => {
                    if (item.type === "folder") {
                      navigateToFolder(item.id, item.title)
                    } else {
                      // Navegar al documento
                      openDocument(item.id)
                    }
                  }}
                >
                  {item.type === "folder" ? (
                    <Folder className="h-10 w-10 text-blue-500" />
                  ) : (
                    <FileText className="h-10 w-10 text-gray-500" />
                  )}
                  <div>
                    <p className="font-medium">{item.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Actualizado el {new Date(item.updated_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Acciones</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => editItem(item)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      <span>Renombrar</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => deleteItem(item.id)}>
                      <Trash2 className="mr-2 h-4 w-4" />
                      <span>Eliminar</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardContent>
            <CardFooter className="p-2 bg-muted/50 flex justify-end">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (item.type === "folder") {
                    navigateToFolder(item.id, item.title)
                  } else {
                    // Abrir documento
                    openDocument(item.id)
                  }
                }}
              >
                {item.type === "folder" ? "Abrir carpeta" : "Editar documento"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {currentItems.length === 0 && !isLoading && (
        <div className="col-span-full h-40 border border-dashed rounded-lg flex items-center justify-center">
          <div className="text-center">
            <File className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
            <p className="text-muted-foreground">No hay documentos en esta carpeta</p>
          </div>
        </div>
      )}

      {/* Diálogo de edición */}
      <EditDocumentDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        document={selectedDocument}
        onDocumentUpdated={fetchDocuments}
      />
    </div>
  )
}
