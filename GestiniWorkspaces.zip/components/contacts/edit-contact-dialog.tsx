"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { Tables } from "@/lib/types/database.types"

type Contact = Tables<"contacts"> & {
  tags: string[]
}

interface EditContactDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  contact: Contact | null
  onContactUpdated: () => void
}

export function EditContactDialog({ open, onOpenChange, contact, onContactUpdated }: EditContactDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [editedContact, setEditedContact] = useState<Partial<Contact>>({})
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")
  const [allTags, setAllTags] = useState<string[]>([])

  // Cargar datos del contacto cuando se abre el diálogo
  useEffect(() => {
    if (contact && open) {
      setEditedContact({
        name: contact.name,
        email: contact.email,
        phone: contact.phone,
        company: contact.company,
        position: contact.position,
        location: contact.location,
        notes: contact.notes,
        favorite: contact.favorite,
      })
      setTags(contact.tags || [])
      fetchAllTags()
    }
  }, [contact, open])

  // Obtener todas las etiquetas existentes
  const fetchAllTags = async () => {
    try {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("contact_tags").select("tag").order("tag")

      if (error) {
        throw error
      }

      // Extraer etiquetas únicas
      const uniqueTags = Array.from(new Set(data.map((item) => item.tag)))
      setAllTags(uniqueTags)
    } catch (error) {
      console.error("Error al obtener etiquetas:", error)
    }
  }

  const handleSave = async () => {
    if (!contact || !editedContact.name || !editedContact.email) {
      toast({
        title: "Error",
        description: "El nombre y el email son obligatorios.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseClient()

      // Actualizar el contacto
      const { error: updateError } = await supabase
        .from("contacts")
        .update({
          name: editedContact.name,
          email: editedContact.email,
          phone: editedContact.phone || null,
          company: editedContact.company || null,
          position: editedContact.position || null,
          location: editedContact.location || null,
          notes: editedContact.notes || null,
          favorite: editedContact.favorite || false,
          updated_at: new Date().toISOString(),
        })
        .eq("id", contact.id)

      if (updateError) {
        throw updateError
      }

      // Eliminar todas las etiquetas existentes
      const { error: deleteTagsError } = await supabase.from("contact_tags").delete().eq("contact_id", contact.id)

      if (deleteTagsError) {
        throw deleteTagsError
      }

      // Añadir las nuevas etiquetas
      if (tags.length > 0) {
        const tagInserts = tags.map((tag) => ({
          contact_id: contact.id,
          tag: tag,
        }))

        const { error: insertTagsError } = await supabase.from("contact_tags").insert(tagInserts)

        if (insertTagsError) {
          throw insertTagsError
        }
      }

      toast({
        title: "Contacto actualizado",
        description: "El contacto ha sido actualizado correctamente.",
      })

      onContactUpdated()
      onOpenChange(false)
    } catch (error: any) {
      console.error("Error al actualizar contacto:", error)
      toast({
        title: "Error",
        description: error.message || "Error al actualizar el contacto. Por favor, intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const addTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag])
      setNewTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleSelectTag = (value: string) => {
    if (value && !tags.includes(value)) {
      setTags([...tags, value])
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>Editar contacto</DialogTitle>
          <DialogDescription>Actualiza la información del contacto.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nombre completo *</Label>
              <Input
                id="name"
                value={editedContact.name || ""}
                onChange={(e) => setEditedContact({ ...editedContact, name: e.target.value })}
                placeholder="Nombre y apellidos"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={editedContact.email || ""}
                onChange={(e) => setEditedContact({ ...editedContact, email: e.target.value })}
                placeholder="email@ejemplo.com"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="phone">Teléfono</Label>
              <Input
                id="phone"
                value={editedContact.phone || ""}
                onChange={(e) => setEditedContact({ ...editedContact, phone: e.target.value })}
                placeholder="+34 600 000 000"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="location">Ubicación</Label>
              <Input
                id="location"
                value={editedContact.location || ""}
                onChange={(e) => setEditedContact({ ...editedContact, location: e.target.value })}
                placeholder="Ciudad, País"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="company">Empresa</Label>
              <Input
                id="company"
                value={editedContact.company || ""}
                onChange={(e) => setEditedContact({ ...editedContact, company: e.target.value })}
                placeholder="Nombre de la empresa"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="position">Cargo</Label>
              <Input
                id="position"
                value={editedContact.position || ""}
                onChange={(e) => setEditedContact({ ...editedContact, position: e.target.value })}
                placeholder="Cargo o puesto"
              />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="tags">Etiquetas</Label>
            <div className="flex gap-2">
              <Input
                id="new-tag"
                placeholder="Añadir etiqueta"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    addTag()
                  }
                }}
              />
              <Select onValueChange={handleSelectTag}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Etiquetas comunes" />
                </SelectTrigger>
                <SelectContent>
                  {allTags.map((tag) => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                  <SelectItem value="cliente">Cliente</SelectItem>
                  <SelectItem value="proveedor">Proveedor</SelectItem>
                  <SelectItem value="socio">Socio</SelectItem>
                  <SelectItem value="personal">Personal</SelectItem>
                  <SelectItem value="trabajo">Trabajo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="gap-1">
                    {tag}
                    <button onClick={() => removeTag(tag)} className="ml-1 rounded-full hover:bg-muted">
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="notes">Notas</Label>
            <Input
              id="notes"
              value={editedContact.notes || ""}
              onChange={(e) => setEditedContact({ ...editedContact, notes: e.target.value })}
              placeholder="Información adicional sobre el contacto"
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="favorite"
              checked={editedContact.favorite || false}
              onChange={(e) => setEditedContact({ ...editedContact, favorite: e.target.checked })}
              className="rounded border-gray-300 text-primary focus:ring-primary"
            />
            <Label htmlFor="favorite">Marcar como favorito</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              "Guardar cambios"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
